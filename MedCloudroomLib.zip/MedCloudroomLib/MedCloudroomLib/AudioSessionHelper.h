//
//  AudioSessionHelper.h
//  MedCloudroomLib
//
//  Created by Developer_Yi on 2020/2/25.
//  Copyright © 2020 美迪康yh. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef void (^AudioRoomIDBlock)(int roomID);

typedef void (^JoinRoomIDBlock)(NSString *userID);

typedef void (^LeaveRoomIDBlock)(NSString *userID);

typedef void (^ErrorBlock)(BOOL isCreatingRoomOccur, NSString *error);

@interface AudioSessionHelper : NSObject

/*返回房间ID*/
@property (nonatomic,copy) AudioRoomIDBlock callbackBlock;
/*返回加入用户房间ID*/
@property (nonatomic,copy) JoinRoomIDBlock joinRoomCallbackBlock;
/*返回离开用户房间ID*/
@property (nonatomic,copy) LeaveRoomIDBlock leaveRoomCallbackBlock;
/*返回错误*/
@property (nonatomic,copy) ErrorBlock errorCallbackBlock;

/*扬声器是否开启*/
@property (nonatomic,assign) BOOL isSpeakerOn;

/*麦克是否开启*/
@property (nonatomic,assign) BOOL isMicOn;

/*创建音频回话房间方法*/
-(void)CreateAudioRoomWithRoomID:(AudioRoomIDBlock) block;

/*加入音频房间方法*/
-(void)StartAudioRoom:(int)RoomID Psw:(NSString *)Psw UserID:(NSString *)userid NickName:(NSString *)nickName MainVideo:(NSString *)mainVideo;

/*离开房间方法*/
- (void)_jumpToPMeeting;

/*接收到房间掉线时调用，其他时候不要调用*/
- (void)reEnterMeeting;

/*扬声器事件*/
- (void)speakerAction:(BOOL) isSpeakerOn;

/*麦克风事件*/
- (void)microphoneAction:(BOOL) isMicOn;

/*监听用户加入房间*/
- (void)listenUserJoinRoom:(JoinRoomIDBlock)block;

/*监听用户离开房间*/
- (void)listenUserLeaveRoom:(LeaveRoomIDBlock)block;

/*监听出错（加入房间失败/房间关闭/房间掉线）*/
- (void)listenError:(ErrorBlock)block;
@end

NS_ASSUME_NONNULL_END
