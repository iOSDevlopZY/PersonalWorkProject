//
//  AudioSessionHelper.m
//  MedCloudroomLib
//
//  Created by Developer_Yi on 2020/2/25.
//  Copyright © 2020 美迪康yh. All rights reserved.
//

#import "AudioSessionHelper.h"
#import "SDKUtil.h"
#import "MeetingHelper.h"

@interface AudioSessionHelper ()<CloudroomVideoMeetingCallBack, CloudroomVideoMgrCallBack>
/*是否为创建房间*/
@property (nonatomic, assign) BOOL isCreatingMeeting;
/*加入房间的信息类*/
@property (nonatomic, strong) MeetInfo *meetInfo;
/*创建房间的信息类*/
@property (nonatomic, strong) MeetInfo *createMeetInfo;
/*创建房间的ID*/
@property (nonatomic, copy) NSString *m_CreateUserid;
/*昵称*/
@property (nonatomic, copy) NSString *m_nickname;
/*加入房间的UserID*/
@property (nonatomic, copy) NSString *m_Userid;
/*创建房间还是加入房间对外标志*/
@property (nonatomic,assign) BOOL isCreatingMeetingSymbol;
@end

@implementation AudioSessionHelper

#pragma mark - 初始化init
- (instancetype)init
{
    _isSpeakerOn = false;
    _isMicOn = false;
    _isCreatingMeeting = false;
    self = [super init];// 当前对象self
    if(self != nil)
    {
        // 不灭屏
        [[UIApplication sharedApplication] setIdleTimerDisabled:YES];
        // 更新代理
        CloudroomVideoMgr *cloudroomVideoMgr = [CloudroomVideoMgr shareInstance];
        [cloudroomVideoMgr setMgrCallback:self];
        CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
        [cloudroomVideoMeeting setMeetingCallBack:self];
        CloudroomVideoSDK *cloudroomVideoSDK = [CloudroomVideoSDK shareInstance];
        [cloudroomVideoSDK setServerAddr:@"www.cloudroom.com"];
               
        NSLog(@"------------ 音频房间初始化完成 --------------");
    }
    return self;
}

#pragma mark - dealloc方法
-(void)dealloc
{
      CloudroomVideoMgr *cloudroomVideoMgr = [CloudroomVideoMgr shareInstance];
      [cloudroomVideoMgr removeMgrCallback:self];
      CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
      [cloudroomVideoMeeting removeMeetingCallBack:self];
      
      [[UIApplication sharedApplication] setIdleTimerDisabled:NO];
      NSLog(@"------------ 音频房间销毁 --------------");
}

#pragma mark - 创建音频会议房间方法
-(void)CreateAudioRoomWithRoomID:(AudioRoomIDBlock) block
{
    _isCreatingMeetingSymbol = true;
    _callbackBlock = block;
    [self _handleLogin];
}

#pragma mark - 加入房间
-(void)StartAudioRoom:(int)RoomID Psw:(NSString *)Psw UserID:(NSString *)userid NickName:(NSString *)nickName MainVideo:(NSString *)mainVideo
{
    _isCreatingMeetingSymbol = false;
    _meetInfo = [[MeetInfo alloc] init];
    
    [_meetInfo setID:RoomID];
    [_meetInfo setPswd:Psw];
    
    _m_nickname =nickName;
    _m_Userid =[NSString stringWithFormat:@"%@_%04zd",userid,[self _randomNumFrom:1 to:9999]];

    // 入会操作
    [self _enterMeeting];
}

#pragma mark - 创建房间需要登录
- (void)_handleLogin {
    _isCreatingMeeting = true;
    MeetingHelper *meetingHelper = [MeetingHelper shareInstance];
    [meetingHelper readInfo];
      
    if ([NSString stringCheckEmptyOrNil:meetingHelper.account] ||
          [NSString stringCheckEmptyOrNil:meetingHelper.pswd] ||
          [NSString stringCheckEmptyOrNil:meetingHelper.server])
    {
          [meetingHelper resetInfo];
    }
    
    NSString *nickname = meetingHelper.nickname;
    if ([NSString stringCheckEmptyOrNil:nickname]) {
        nickname = [NSString stringWithFormat:@"iOS_%04zd", [self _randomNumFrom:1000 to:9999]];
    }
    
    // 云屋SDK登陆账号,实际开发中,请联系云屋工作人员获取
    NSString *account = meetingHelper.account;
    // 密码通过MD5以后
    NSString *pswd = meetingHelper.pswd;
    // 服务器地址
    NSString *server = meetingHelper.server;
    
    if ([NSString stringCheckEmptyOrNil:server]) {
        [HUDUtil hudShow:@"服务器地址不能为空!" delay:3 animated:YES];
        return;
    }
    
    if ([NSString stringCheckEmptyOrNil:account]) {
        [HUDUtil hudShow:@"账号不能为空!" delay:3 animated:YES];
        return;
    }
    
    if ([NSString stringCheckEmptyOrNil:pswd]) {
        [HUDUtil hudShow:@"密码不能为空!" delay:3 animated:YES];
        return;
    }
    
    NSString *md5Pswd = [NSString md5:meetingHelper.pswd];
    
    MLog(@"server:%@ nickname:%@ account:%@ pswd:%@", server, nickname, account, md5Pswd);
    
    CloudroomVideoMgr *cloudroomVideoMgr = [CloudroomVideoMgr shareInstance];
    CloudroomVideoSDK *cloudroomVideoSDK = [CloudroomVideoSDK shareInstance];
    LoginDat *loginData = [[LoginDat alloc] init];
    [loginData setNickName:nickname];
    [loginData setAuthAcnt:account];
    [loginData setAuthPswd:md5Pswd];
    [loginData setPrivAcnt:nickname];
    
    [meetingHelper writeAccount:account pswd:pswd server:server];
    [meetingHelper writeNickname:nickname];
    
    // 设置服务器地址
    [cloudroomVideoSDK setServerAddr:server];
    
    [HUDUtil hudShowProgress:@"正在登录中..." animated:YES];
    
    // 开始上传日志
    [[CloudroomVideoSDK shareInstance] startLogReport:nickname server:@"logserver.cloudroom.com:12005"];
    
    // 发送"登录"指令
    NSString *cookie = [NSString stringWithFormat:@"%f",CFAbsoluteTimeGetCurrent()];
    [cloudroomVideoMgr login:loginData cookie:cookie];
}

#pragma mark - 登录密码生成随机码
- (NSInteger)_randomNumFrom:(NSInteger)from to:(NSInteger)to {
    return (from + (NSInteger)(arc4random() % (to - from + 1)));
}

#pragma mark - 登陆成功
- (void)loginSuccess:(NSString *)usrID cookie:(NSString *)cookie {
    [HUDUtil hudHiddenProgress:YES];
    [HUDUtil hudShowProgress:@"正在创建房间..." animated:YES];
    NSLog(@">>>>>>>>>>>>>>创建房间登录用户ID为:%@",usrID);
    _m_CreateUserid = usrID;
    NSString *createCookie = [NSString stringWithFormat:@"%f", CFAbsoluteTimeGetCurrent()];
        // 发送"创建房间"命令(不设置密码)
    [[CloudroomVideoMgr shareInstance] createMeeting:usrID createPswd:NO cookie:createCookie];
}

#pragma mark - 登陆失败
- (void)loginFail:(CRVIDEOSDK_ERR_DEF)sdkErr cookie:(NSString *)cookie {
        
    [HUDUtil hudHiddenProgress:YES];
    
    if (sdkErr == CRVIDEOSDK_NOSERVER_RSP) {
        [HUDUtil hudShow:@"服务器无响应" delay:3 animated:YES];
    }
    else if (sdkErr == CRVIDEOSDK_LOGINSTATE_ERROR) {
        [HUDUtil hudShow:@"登陆状态不对" delay:3 animated:YES];
        [[CloudroomVideoMgr shareInstance] logout];
    }
    else if (sdkErr == CRVIDEOSDK_SOCKETTIMEOUT) {
        [HUDUtil hudShow:@"网络超时" delay:3 animated:YES];
    }
    else {
        [HUDUtil hudShow:@"登录失败" delay:3 animated:YES];
    }
    [self _jumpToPMeeting];
    if(_errorCallbackBlock)
    {
           _errorCallbackBlock(_isCreatingMeetingSymbol,@"LoginFail");
    }
}

#pragma mark - 创建房间成功回调
- (void)createMeetingSuccess:(MeetInfo *)meetInfo cookie:(NSString *)cookie {
    [HUDUtil hudHiddenProgress:YES];
    NSLog(@">>>>>>>>>>>>房间ID为：%d",meetInfo.ID);
    _createMeetInfo = meetInfo;
    //进入房间
    [self _enterCreateRoomMeeting];
}

#pragma mark - 创建房间失败回调
- (void)createMeetingFail:(CRVIDEOSDK_ERR_DEF)sdkErr cookie:(NSString *)cookie {
    [HUDUtil hudHiddenProgress:YES];
    NSLog(@"创建房间失败：%u",sdkErr );
    [HUDUtil hudShow:@"创建房间失败" delay:3 animated:YES];
  
    [self _jumpToPMeeting];
    
    if(_errorCallbackBlock)
    {
         _errorCallbackBlock(_isCreatingMeetingSymbol,@"CreateRoomFail");
    }
}

#pragma mark - 进入创建的房间
- (void)_enterCreateRoomMeeting{
        if (_createMeetInfo.ID > 0) {
           [HUDUtil hudShowProgress:@"正在进入房间..." animated:YES];
           _isCreatingMeeting = true;
           CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
           [cloudroomVideoMeeting enterMeeting:_createMeetInfo.ID pswd:_createMeetInfo.pswd userID:_m_CreateUserid nikeName:_m_CreateUserid];
       }
}

#pragma mark - 进入别人的房间
- (void)_enterMeeting {
    if (_meetInfo.ID > 0) {
        
        [HUDUtil hudShowProgress:@"正在进入房间..." animated:YES];
        CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
        
        
        [cloudroomVideoMeeting enterMeeting:_meetInfo.ID pswd:_meetInfo.pswd userID:_m_Userid nikeName:_m_nickname];
    }
}
#pragma mark - 处理进入房间
- (void)enterMeetingRslt:(CRVIDEOSDK_ERR_DEF)code {
    
    [HUDUtil hudHiddenProgress:YES];
    
    if (code == CRVIDEOSDK_NOERR) {
        [self _enterMeetingSuccess];
    } else if (code == CRVIDEOSDK_MEETROOMLOCKED) {
        [self _enterMeetingFail:@"房间已加锁!"];
    } else {
        NSLog(@">>>>>进入房间失败！错误码：%d",code);
        [self _enterMeetingFail:@"进入房间失败!"];
    }
}
#pragma mark - 进入房间成功
- (void)_enterMeetingSuccess {
    if(_createMeetInfo.ID > 0 && _isCreatingMeeting)
        _callbackBlock(_createMeetInfo.ID);
    // 打开本地麦克风
    [SDKUtil openLocalMic];
    _isSpeakerOn = true;
    _isMicOn = true;
}

#pragma mark - 进入房间失败
- (void)_enterMeetingFail:(NSString *)message {
    [HUDUtil hudShow:[NSString stringWithFormat:@"进入房间失败，错误原因：%@",message] delay:3 animated:YES];
    [self _jumpToPMeeting];
    if(_errorCallbackBlock)
    {
            _errorCallbackBlock(_isCreatingMeetingSymbol,@"EnterRoomFail");
    }
}

#pragma mark - 房间被结束
- (void)meetingStopped{
     [HUDUtil hudShow:@"房间已结束" delay:3 animated:YES];
     [self _jumpToPMeeting];
    if(_errorCallbackBlock)
    {
       _errorCallbackBlock(_isCreatingMeetingSymbol,@"RoomStopped");
    }
}

#pragma mark - 房间掉线
- (void)meetingDropped{
    NSLog(@"房间掉线!");
    [HUDUtil hudShow:@"房间掉线" delay:3 animated:YES];
    if(_errorCallbackBlock)
    {
       _errorCallbackBlock(_isCreatingMeetingSymbol,@"RoomDropped");
    }
}

#pragma mark - 房间重连的方法
- (void)reEnterMeeting{
    // 离开房间
   [[CloudroomVideoMeeting shareInstance] exitMeeting];
         // 重新入会
    if(_isCreatingMeeting)
    {
             [self _enterCreateRoomMeeting];
    }
    else
    {
             [self _enterMeeting];
    }
}

#pragma mark - 离开会议
- (void)_jumpToPMeeting {
     _isSpeakerOn = false;
     _isMicOn = false;
    [HUDUtil hudShow:@"离开房间" delay:3 animated:YES];
    // 离开房间
    [[CloudroomVideoMeeting shareInstance] exitMeeting];
    // 注销
    [[CloudroomVideoMgr shareInstance] logout];
    _createMeetInfo = nil;
    _meetInfo = nil;
    _m_CreateUserid = nil;
    _isCreatingMeeting = false;
    _m_nickname = nil;
    _m_Userid = nil;
    NSLog(@"------------ 退出房间 --------------");
}

#pragma mark - 扬声器事件
- (void)speakerAction:(BOOL) isSpeakerOn{
    
    _isSpeakerOn = isSpeakerOn;
    
    CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
    
    if(!isSpeakerOn){
        
        [cloudroomVideoMeeting setSpeakerMute:YES];
        [HUDUtil hudShow:@"关闭扬声器" delay:2 animated:YES];
    }
    else{
        [cloudroomVideoMeeting setSpeakerMute:NO];
        [HUDUtil hudShow:@"开启扬声器" delay:2 animated:YES];
    }
}

#pragma mark -  麦克风事件
- (void)microphoneAction:(BOOL) isMicOn{
    
    _isMicOn = isMicOn;
    if (!isMicOn) {
        
        [SDKUtil closeLocalMic];
        
        [HUDUtil hudShow:@"关闭麦克风" delay:2 animated:YES];

        
    } else {
        [SDKUtil openLocalMic];
        [HUDUtil hudShow:@"开启麦克风" delay:2 animated:YES];
    }
    
}

#pragma mark - 用户加入房间
- (void)userEnterMeeting:(NSString *)userID {
    NSString *text = [NSString stringWithFormat:@"%@进入房间!", [[CloudroomVideoMeeting shareInstance] getNickName:userID]];
    [HUDUtil hudShow:text delay:2 animated:YES];
    if(_joinRoomCallbackBlock)
    {
        _joinRoomCallbackBlock(userID);
    }
}

#pragma mark - 用户离开房间
- (void)userLeftMeeting:(NSString *)userID {
    NSString *text = [NSString stringWithFormat:@"%@离开房间!", [[CloudroomVideoMeeting shareInstance] getNickName:userID]];
    [HUDUtil hudShow:text delay:2 animated:YES];

    if(_leaveRoomCallbackBlock)
    {
        _leaveRoomCallbackBlock(userID);
    }
}

#pragma mark - 监听加入用户房间
- (void)listenUserJoinRoom:(JoinRoomIDBlock)block
{
    _joinRoomCallbackBlock = block;
}

#pragma mark - 监听用户离开房间
- (void)listenUserLeaveRoom:(LeaveRoomIDBlock)block
{
    _leaveRoomCallbackBlock = block;
}

#pragma mark - 监听出错
- (void)listenError:(ErrorBlock)block
{
    _errorCallbackBlock = block;
}
@end
