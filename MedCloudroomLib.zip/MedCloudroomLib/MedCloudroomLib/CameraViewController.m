//
//  CameraViewController.m
//  iOSCameraViewWithDrawing
//
//  Created by zhangyi on 2020/7/17.
//  Copyright © 2020 medcare. All rights reserved.
//

#import "CameraViewController.h"
#import <Photos/Photos.h>
#import <AVFoundation/AVFoundation.h>

#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height
@interface CameraViewController () <AVCapturePhotoCaptureDelegate>

// 自定义相机（AVFoundation）
@property (nonatomic, strong) AVCaptureSession *session;                 // 会话
@property (nonatomic, strong) AVCaptureDevice *device;                   // 设备
@property (nonatomic, strong) AVCaptureDeviceInput *input;               // 设备输入
@property (nonatomic, strong) AVCapturePhotoOutput *output;              // 设备输出
@property (nonatomic, strong) AVCaptureConnection *connection;           // 连接
@property (nonatomic, strong) AVCaptureVideoPreviewLayer *preViewLayer;  // 预览图层
@property (nonatomic, strong) AVCapturePhotoSettings *outputSettings;    // 拍照设置

// 界面
@property (nonatomic, strong) UIView *topView;                           // 顶部视图
@property (nonatomic, strong) UIView *middleView;                        // 中部视图
@property (nonatomic, strong) UIView *bottomView;                        // 底部视图

@property (nonatomic, strong) UIButton *backButton;                      // 返回按钮
@property (nonatomic, strong) UIButton *cameraButton;                    // 拍照按钮
@property (nonatomic, strong) UIButton *switchCameraButton;              // 切换摄像头按钮

@end

@implementation CameraViewController

#pragma mark - 生存周期
- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [_session startRunning];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    [self setCustomCamera];
    [self setupUI];
    // 切换为前置摄像头
    [self swapFrontAndBackCameras];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [_session stopRunning];
}

#pragma mark - 设置UI
- (void)setupUI{
    [self setMiddelViewUI];
    [self setTopViewUI];
    [self setBottomViewUI];
}

- (void)setTopViewUI{
    _topView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight*0.2)];
    _topView.backgroundColor = [UIColor clearColor];
    _backButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 30, 25)];
    [_backButton setCenter:CGPointMake(kScreenWidth * 0.9, _topView.frame.size.height/2)];
    [_backButton setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    [_backButton addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    
    _switchCameraButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 50, 50)];
    [_switchCameraButton setCenter:CGPointMake(kScreenWidth * 0.1 - 5, _topView.frame.size.height/2)];
    [_switchCameraButton.imageView setContentMode:UIViewContentModeScaleAspectFit];
    [_switchCameraButton setImage:[UIImage imageNamed:@"switchCamera"] forState:UIControlStateNormal];
    [_switchCameraButton addTarget:self action:@selector(swapFrontAndBackCameras) forControlEvents:UIControlEventTouchUpInside];
    
    [_topView addSubview:_backButton];
//    [_topView addSubview:_switchCameraButton];
    [_middleView addSubview:_topView];
}

- (void)setMiddelViewUI{
    _middleView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight)];
    _middleView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:_middleView];
    _preViewLayer.frame = _middleView.bounds;
    [_middleView.layer addSublayer:_preViewLayer];
    
    UIImageView *tongueView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight)];
    tongueView.image = [UIImage imageNamed:@"tongue"];
    tongueView.contentMode = UIViewContentModeScaleAspectFit;
    [_middleView addSubview:tongueView];
    [_middleView bringSubviewToFront:tongueView];
}

- (void)setBottomViewUI{
    _bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, kScreenHeight*0.8, kScreenWidth, kScreenHeight*0.2)];
    _bottomView.backgroundColor = [UIColor clearColor];
    _cameraButton = [[UIButton alloc]initWithFrame:CGRectMake(kScreenWidth *0.3,(_bottomView.frame.size.height - kScreenWidth*0.35) * 0.5, kScreenWidth*0.35, kScreenWidth*0.35)];
    [_cameraButton.imageView setContentMode:UIViewContentModeScaleAspectFit];
    [_cameraButton setImage:[UIImage imageNamed:@"takePhoto"] forState:UIControlStateNormal];
    [_cameraButton addTarget:self action:@selector(takePhoto) forControlEvents:UIControlEventTouchUpInside];
    [_bottomView addSubview:_cameraButton];
    [_middleView addSubview:_bottomView];
}

#pragma mark - 设置自定义相机
- (void)setCustomCamera{
    _session = [[AVCaptureSession alloc]init];
    [_session setSessionPreset:AVCaptureSessionPresetHigh];
    _device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];

    NSError *error = nil;
    _input = [[AVCaptureDeviceInput alloc] initWithDevice:_device error:&error];
    if (error) {
        [self showAlertMsg:@"创建视频输入设备失败"];
        return;
    }
    
    AVCapturePhotoOutput *output = [[AVCapturePhotoOutput alloc] init];
    _output = output;
    NSDictionary *setDic = @{AVVideoCodecKey:AVVideoCodecJPEG};
    _outputSettings = [AVCapturePhotoSettings photoSettingsWithFormat:setDic];
    
    [_output setPhotoSettingsForSceneMonitoring:_outputSettings];
   
    if ([_session canSetSessionPreset:AVCaptureSessionPreset1280x720]) {
        [_session setSessionPreset:AVCaptureSessionPreset1280x720];
    }
        
    if ([_session canAddInput:_input]) {
        [_session addInput:_input];
    }else {
        [self showAlertMsg:@"添加输入设备失败"];
        return;
    }
    if ([_session canAddOutput:output]) {
           [_session addOutput:output];
    }else {
        [self showAlertMsg:@"添加输出设备失败"];
        return;
    }
       
    AVCaptureVideoPreviewLayer *layer = [AVCaptureVideoPreviewLayer layerWithSession:_session];
    layer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    _preViewLayer = layer;
}

#pragma mark - 辅助函数
- (void)showAlertMsg:(NSString*)msg{
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:@"提示" message:msg preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleDefault handler:nil];
    [ac addAction:okAction];
    [self presentViewController:ac animated:YES completion:nil];
}

#pragma mark - 离开相机
- (void)back{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - 拍照
- (void)takePhoto{
    _connection = [_output connectionWithMediaType:AVMediaTypeVideo];
    AVCapturePhotoSettings *settings = [[AVCapturePhotoSettings alloc]init];
    [_output capturePhotoWithSettings:settings delegate:self];
}

# pragma mark - AVCapturePhotoCaptureDelegate
- (void)captureOutput:(AVCapturePhotoOutput *)output didFinishProcessingPhotoSampleBuffer:(CMSampleBufferRef)photoSampleBuffer previewPhotoSampleBuffer:(CMSampleBufferRef)previewPhotoSampleBuffer resolvedSettings:(AVCaptureResolvedPhotoSettings *)resolvedSettings bracketSettings:(AVCaptureBracketedStillImageSettings *)bracketSettings error:(NSError *)error{
       // RAW格式数据
//    NSData *data = [AVCapturePhotoOutput DNGPhotoDataRepresentationForRawSampleBuffer:photoSampleBuffer previewPhotoSampleBuffer:previewPhotoSampleBuffer];
       // JPG格式
       NSData *data = [AVCapturePhotoOutput JPEGPhotoDataRepresentationForJPEGSampleBuffer:photoSampleBuffer previewPhotoSampleBuffer:previewPhotoSampleBuffer];
       UIImage *image = [UIImage imageWithData:data];
       UIImageWriteToSavedPhotosAlbum(image, self, @selector(image:didFinishSavingWithError:contextInfo:), nil);
}

#pragma mark - 照片存入相册完毕
- (void)image:(UIImage*)img didFinishSavingWithError:(NSError*)err contextInfo:(void*)info{
    NSLog(@"照片存储完毕");
}

#pragma mark - 获取相机位置
- (AVCaptureDevice *)cameraWithPosition:(AVCaptureDevicePosition)position{
    AVCaptureDeviceDiscoverySession *devices = [AVCaptureDeviceDiscoverySession discoverySessionWithDeviceTypes:@[AVCaptureDeviceTypeBuiltInWideAngleCamera] mediaType:AVMediaTypeVideo position:position];
    
    NSArray *devicesAll = devices.devices;
    for (AVCaptureDevice *device in devicesAll) {
        if ([device position] == position) {
            return device;
        }
    }
    return nil;
}

# pragma mark - 切换前后相机
- (void)swapFrontAndBackCameras {
    NSArray *inputs = _session.inputs;
    for ( AVCaptureDeviceInput *input in inputs ) {
        AVCaptureDevice *device = input.device;
        if ( [device hasMediaType:AVMediaTypeVideo] ) {
            AVCaptureDevicePosition position = device.position;
            AVCaptureDevice *newCamera = nil;
            AVCaptureDeviceInput *newInput = nil;
 
            if (position == AVCaptureDevicePositionFront)
                newCamera = [self cameraWithPosition:AVCaptureDevicePositionBack];
            else
                newCamera = [self cameraWithPosition:AVCaptureDevicePositionFront];
            newInput = [AVCaptureDeviceInput deviceInputWithDevice:newCamera error:nil];
 
            // 开始切换
            [_session beginConfiguration];
 
            [_session removeInput:input];
            [_session addInput:newInput];
 
            // 结束切换
            [_session commitConfiguration];
            break;
        }
    }
}
@end
