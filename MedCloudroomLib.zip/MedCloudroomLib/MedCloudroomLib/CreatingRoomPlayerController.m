//
//  CreatingRoomPlayerController.m
//  MedCloudroomLib
//
//  Created by Developer_Yi on 2020/2/21.
//  Copyright © 2020 美迪康yh. All rights reserved.
//

#import "CreatingRoomPlayerController.h"
#import "CustomCameraView.h"
#import "SDKUtil.h"
#import "HUDUtil.h"
#import "Masonry.h"
#import "MyCell.h"
#import "MeetingHelper.h"
#import "JHCustomMenu.h"
#import "PatientInfoWebViewController.h"

#define WeakSelf __weak typeof(self) weakSelf = self;



@interface CreatingRoomPlayerController ()<CloudroomVideoMeetingCallBack, CloudroomVideoMgrCallBack,UICollectionViewDataSource,UICollectionViewDelegate,UIScrollViewDelegate,UICollectionViewDelegateFlowLayout,JHCustomMenuDelegate>

@property(nonatomic,assign)BOOL isLandScape;
/*屏幕宽度*/
@property(nonatomic,assign)CGFloat Screen_width;
/*屏幕高度*/
@property(nonatomic,assign)CGFloat Screen_height;
/*更新锁*/
@property(nonatomic,strong)NSLock *ArrLock;
/*隐藏状态栏*/
@property(nonatomic,assign)BOOL StateBarIsHidden;
/*是否屏幕共享*/
@property(nonatomic,assign)BOOL isScreenShare;
/*麦克是否关闭*/
@property(nonatomic,assign)BOOL MicisClose;
/*本地摄像头是否关闭*/
@property(nonatomic,assign)BOOL CameraisClose;
/*麦克风是否关闭*/
@property(nonatomic,assign)BOOL SpeakerisClose;
/*房间标题*/
@property (nonatomic, copy) NSString *titleStr;
/*创建房间的ID*/
@property (nonatomic, copy) NSString *m_CreateUserid;
/*昵称*/
@property (nonatomic, copy) NSString *m_nickname;
/*加入房间的UserID*/
@property (nonatomic, copy) NSString *m_Userid;
/*是否为创建房间*/
@property (nonatomic, assign) BOOL isCreatingMeeting;
/*加入房间的信息类*/
@property (nonatomic, strong) MeetInfo *meetInfo;
/*创建房间的信息类*/
@property (nonatomic, strong) MeetInfo *createMeetInfo;
/*主视频view*/
@property(nonatomic,strong)UIView *InfoView;
/*退出按钮*/
@property(nonatomic,strong)UIButton *EndButton;
/*更多按钮*/
@property(nonatomic,strong)UIButton *moreButton;
/*挂断按钮*/
@property(nonatomic,strong)UIButton *hangoutButton;
/*外放按钮*/
@property(nonatomic,strong)UIButton *SoundButton;
/*麦克按钮*/
@property(nonatomic,strong)UIButton *MicButton;
/*摄像头按钮*/
@property(nonatomic,strong)UIButton *CameraButton;
/*标题*/
@property(nonatomic,strong)UILabel *TitleLabel;
@property(nonatomic,strong)UIView *TopView; 
/*主布局*/
@property(nonatomic,strong)UIView *MainVideoView;
/*自己摄像头视图*/
@property(nonatomic,strong)CustomCameraView *selfCameraView;
/*主屏幕视图*/
@property(nonatomic,strong)CustomCameraView *cusCameraView;
/*相机列表*/
@property (nonatomic, copy) NSArray<UsrVideoInfo *> *cameraArray;
 /* 当前摄像头索引 */
@property (nonatomic, assign) NSInteger curCameraIndex;
/*房间成员列表*/
@property (nonatomic, strong) NSMutableArray<UsrVideoId *> *members;
/*下拉菜单*/
@property (nonatomic, strong) JHCustomMenu *popMenu;
/*下拉菜单名字*/
@property (nonatomic, strong) NSArray *titleArray;
/*下拉菜单logo*/
@property (nonatomic, strong) NSArray *logoArrary;
/*是否显示*/
@property (nonatomic, assign) BOOL isShowMore;
@end

@implementation CreatingRoomPlayerController

#pragma mark - view即将展现
- (void)viewWillAppear:(BOOL)animated{
       _isCreatingMeeting = false;
       _isLandScape = false;
       
       // 不灭屏
       [[UIApplication sharedApplication] setIdleTimerDisabled:YES];
       // 更新代理
       CloudroomVideoMgr *cloudroomVideoMgr = [CloudroomVideoMgr shareInstance];
       [cloudroomVideoMgr setMgrCallback:self];
       CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
       [cloudroomVideoMeeting setMeetingCallBack:self];
        
//       [self layoutSubView];
       // 使用新布局
       [self layoutSubViewNew];
}

#pragma mark - view已经加载
- (void)viewDidLoad {
    [super viewDidLoad];
    _curCameraIndex = 1;
    self.ArrLock = [[NSLock alloc]init];
        
    [self.view setBackgroundColor:[UIColor blackColor]];
        
    NSNumber *orientationTarget = [NSNumber numberWithInt:UIInterfaceOrientationPortrait];
        [[UIDevice currentDevice] setValue:orientationTarget forKey:@"orientation"];

        
    CloudroomVideoSDK *cloudroomVideoSDK = [CloudroomVideoSDK shareInstance];
    [cloudroomVideoSDK setServerAddr:@"www.cloudroom.com"];
        
    NSLog(@"------------ 播放器初始化 --------------");
        
        
    _Screen_width =self.view.bounds.size.width;
    _Screen_height =self.view.bounds.size.height;
        
    _isDismiss = NO;
    _StateBarIsHidden = NO;
    _isScreenShare = NO;
    _MicisClose = NO;
    _CameraisClose = NO;
    _SpeakerisClose = YES;
}

#pragma mark - view确实显示
-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
//    [self MainVideoTapAction];
}

#pragma mark - view即将消失
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    
    CloudroomVideoMgr *cloudroomVideoMgr = [CloudroomVideoMgr shareInstance];
    [cloudroomVideoMgr removeMgrCallback:self];
    CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
    [cloudroomVideoMeeting removeMeetingCallBack:self];
    
    [[UIApplication sharedApplication] setIdleTimerDisabled:NO];

    
}

#pragma mark - view已经消失
-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    
    _isDismiss = YES;
}

#pragma mark - 设置布局
- (void)layoutSubView{
      WeakSelf
        // 主屏底部View
        [self.view addSubview:self.MainVideoView];
        
        [_MainVideoView setBackgroundColor:[UIColor blackColor]];
        
        [_MainVideoView makeConstraints:^(MASConstraintMaker *make) {
           
            make.top.equalTo(weakSelf.view.top);
            make.left.equalTo(weakSelf.view.left);
            make.width.equalTo(weakSelf.view);
            make.height.equalTo(weakSelf.view);
            
        }];
        
        // 信息栏
        [self.view addSubview:self.InfoView];
        
        [_InfoView setBackgroundColor:UIColorFromRGBA(1, 101, 184, 1.0)];

        [_InfoView makeConstraints:^(MASConstraintMaker *make) {
            
            make.top.equalTo(weakSelf.view.top);
            make.left.equalTo(weakSelf.view.left);
            make.width.equalTo(weakSelf.view);
            make.height.equalTo(@64);
            
        }];

        
        // 工具栏
        [self.view addSubview:self.TopView];
        [_TopView setBackgroundColor:UIColorFromRGBA(25, 25, 25, 1.0)];

        [_TopView makeConstraints:^(MASConstraintMaker *make) {
            
            make.bottom.equalTo(weakSelf.view.bottom);
            make.left.equalTo(weakSelf.view.left);
            make.right.equalTo(weakSelf.view.right);
            make.height.equalTo(@40);
            
        }];
        
        
        
        // 预览
        [_MainVideoView addSubview:self.selfCameraView];
            
        [_selfCameraView makeConstraints:^(MASConstraintMaker *make) {

            make.top.equalTo(weakSelf.InfoView.mas_bottom).with.offset(10);
            make.right.equalTo(weakSelf.MainVideoView.right);
            make.width.equalTo(@120);
            make.height.equalTo(@120);
        
        }];
        
        _selfCameraView.layer.borderWidth = 1.0;
        _selfCameraView.layer.borderColor = [UIColor grayColor].CGColor;
        
        
        [_selfCameraView setUsrVideoId:nil];
        
        // 主视频
        [_MainVideoView addSubview:self.cusCameraView];
        
        UITapGestureRecognizer *tapEvent = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(MainVideoTapAction)];
        
        [_cusCameraView addGestureRecognizer:tapEvent];
        
        
        [_cusCameraView makeConstraints:^(MASConstraintMaker *make) {
            
            
            make.top.equalTo(weakSelf.selfCameraView.mas_bottom).with.offset(10);
            make.left.equalTo(weakSelf.MainVideoView.left);
            make.width.equalTo(weakSelf.MainVideoView);
            make.bottom.equalTo(weakSelf.TopView.top).with.offset(-20);
            
        }];
        _cusCameraView.layer.borderWidth = 1.0;
        _cusCameraView.layer.borderColor = [UIColor grayColor].CGColor;
        [_cusCameraView setUsrVideoId:nil];
        
        // 退出
        _EndButton = [UIButton buttonWithType:UIButtonTypeSystem];
        [_InfoView addSubview:_EndButton];

        
        [_EndButton setTitle:@"离开" forState:UIControlStateNormal];
        [_EndButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        
        [_EndButton makeConstraints:^(MASConstraintMaker *make) {
           
            make.top.equalTo(_InfoView.top).with.offset(20);
            make.bottom.equalTo(_InfoView.bottom);
            make.right.equalTo(_InfoView.right).with.offset(-10);
            make.width.equalTo(@40);

        }];

        [_EndButton addTarget:self action:@selector(_handleExit) forControlEvents:(UIControlEventTouchUpInside)];

        // 外放按钮
        _SoundButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_InfoView addSubview:_SoundButton];
        
        [_SoundButton setImage:[UIImage imageNamed:@"bt_sound_Off"] forState:UIControlStateNormal];
        
        _SoundButton.imageView.contentMode = UIViewContentModeScaleAspectFit;
        
        [_SoundButton makeConstraints:^(MASConstraintMaker *make) {
            
            make.top.equalTo(_InfoView.top).with.offset(20);
            make.bottom.equalTo(_InfoView.bottom);
            make.left.equalTo(_InfoView.left).with.offset(10);
            make.width.equalTo(@40);

            
        }];
        
        [_SoundButton addTarget:self action:@selector(SoundBtAction) forControlEvents:(UIControlEventTouchUpInside)];
        
        
        // 房间标题
        [_InfoView addSubview:self.TitleLabel];
        [_TitleLabel makeConstraints:^(MASConstraintMaker *make) {
            
            make.top.equalTo(_InfoView.top).with.offset(20);
            make.bottom.equalTo(_InfoView.bottom);
            make.right.equalTo(_EndButton.left);
            make.left.equalTo(_SoundButton.right);
        }];
        [_TitleLabel setTextAlignment:NSTextAlignmentCenter];
        [_TitleLabel setTextColor:[UIColor whiteColor]];

        // 麦克风按钮
        _MicButton = [UIButton buttonWithType:UIButtonTypeSystem];
        [_TopView addSubview:_MicButton];
        
        [_MicButton setImage:[UIImage imageNamed:@"bt_mic_On"] forState:UIControlStateNormal];
        
        [_MicButton makeConstraints:^(MASConstraintMaker *make) {
            
            make.top.equalTo(_TopView.top);
            make.bottom.equalTo(_TopView.bottom);
            make.left.equalTo(_TopView.left).with.offset(50);
            make.width.equalTo(@40);
            
        }];
        
        [_MicButton addTarget:self action:@selector(MicrophoneBtAction) forControlEvents:(UIControlEventTouchUpInside)];

        
        
        // 摄像头按钮
        _CameraButton = [UIButton buttonWithType:UIButtonTypeSystem];
        [_TopView addSubview:_CameraButton];
        
        [_CameraButton setImage:[UIImage imageNamed:@"bt_camera_On"] forState:UIControlStateNormal];
        
        [_CameraButton makeConstraints:^(MASConstraintMaker *make) {
            
            make.top.equalTo(_TopView.top);
            make.bottom.equalTo(_TopView.bottom);
            make.right.equalTo(_TopView.right).with.offset(-50);
            make.width.equalTo(@40);
            
        }];
        
        [_CameraButton addTarget:self action:@selector(CameraBtAction) forControlEvents:(UIControlEventTouchUpInside)];
    
}

#pragma mark - 设置新布局
- (void)layoutSubViewNew{

        // 主屏底部View
   
        [self.view addSubview:self.MainVideoView];
        [self.MainVideoView setFrame:CGRectMake(0, 0, _Screen_width, _Screen_height)];
        [_MainVideoView setBackgroundColor:[UIColor blackColor]];
        
        // 主视频
        [_MainVideoView addSubview:self.cusCameraView];
        [self.cusCameraView setFrame:CGRectMake(0, 0, _Screen_width, _Screen_height)];
        [_cusCameraView setUsrVideoId:nil];
//        UITapGestureRecognizer *tapEvent = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(MainVideoTapAction)];
//
//        [_cusCameraView addGestureRecognizer:tapEvent];
        //顶部栏
        [self.cusCameraView addSubview:self.InfoView];
               
        [_InfoView setBackgroundColor:UIColorFromRGBA(1, 101, 184, 0)];

        [self.InfoView setFrame:CGRectMake(0, 0, _Screen_width, 64)];
    
        // 退出
         _EndButton = [UIButton buttonWithType:UIButtonTypeCustom];
         [_InfoView addSubview:_EndButton];
           
        [_EndButton setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
        [_EndButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self.EndButton setFrame:CGRectMake(_Screen_width*0.05, 20, 40, 40)];

        _EndButton.imageView.contentMode = UIViewContentModeScaleAspectFit;
        [_EndButton addTarget:self action:@selector(_handleExit) forControlEvents:(UIControlEventTouchUpInside)];
    
        // 更多
        _moreButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_InfoView addSubview:_moreButton];
        [self.moreButton setFrame:CGRectMake(_Screen_width*0.95 - 40, 20, 40, 40)];
    
        [_moreButton setImage:[UIImage imageNamed:@"moreh"] forState:UIControlStateNormal];
        [_moreButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _moreButton.imageView.contentMode = UIViewContentModeScaleAspectFit;
        [_moreButton addTarget:self action:@selector(_more) forControlEvents:(UIControlEventTouchUpInside)];
        [_moreButton setHidden:!_isShowMore];
        // 预览
       
        self.selfCameraView = [[CustomCameraView alloc]initWithFrame:CGRectMake(_Screen_width*0.7, 74, _Screen_width*0.3, _Screen_height*0.2)];
        [_cusCameraView addSubview:_selfCameraView];

        
        _selfCameraView.layer.borderWidth = 1.0;
        _selfCameraView.layer.borderColor = [UIColor grayColor].CGColor;
        
        
        [_selfCameraView setUsrVideoId:nil];
        
        // 底部工具栏
        self.TopView = [[UIView alloc]initWithFrame:CGRectMake(0, _Screen_height*0.8, _Screen_width, _Screen_height*0.2)];
        [self.cusCameraView addSubview:self.TopView];
        [_TopView setBackgroundColor:UIColorFromRGBA(125, 125, 125, 0)];

        // 挂断按钮
        _hangoutButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_TopView addSubview:_hangoutButton];
        [_hangoutButton setFrame:CGRectMake(_Screen_width*0.4, 0, _Screen_width*0.2, _Screen_height*0.2)];
       _hangoutButton.imageView.contentMode = UIViewContentModeScaleAspectFit;
       [_hangoutButton setImage:[UIImage imageNamed:@"hangout"] forState:UIControlStateNormal];
       [_hangoutButton addTarget:self action:@selector(_handleExit) forControlEvents:(UIControlEventTouchUpInside)];
        // 外放按钮
          _SoundButton = [UIButton buttonWithType:UIButtonTypeCustom];
          [_TopView addSubview:_SoundButton];

          [_SoundButton setImage:[UIImage imageNamed:@"bt_sound_Off"] forState:UIControlStateNormal];

          _SoundButton.imageView.contentMode = UIViewContentModeScaleAspectFit;
           [_SoundButton setFrame:CGRectMake(_Screen_width*0.1, _hangoutButton.frame.size.height/4, _Screen_width*0.1, _hangoutButton.frame.size.height/2)];

          [_SoundButton addTarget:self action:@selector(SoundBtAction) forControlEvents:(UIControlEventTouchUpInside)];

          // 麦克风按钮
           _MicButton = [UIButton buttonWithType:UIButtonTypeCustom];
           [_TopView addSubview:_MicButton];

           [_MicButton setImage:[UIImage imageNamed:@"bt_mic_On"] forState:UIControlStateNormal];
           _MicButton.imageView.contentMode = UIViewContentModeScaleAspectFit;
            [_MicButton setFrame:CGRectMake(_Screen_width*0.8, _hangoutButton.frame.size.height/4, _Screen_width*0.1, _hangoutButton.frame.size.height/2)];


           [_MicButton addTarget:self action:@selector(MicrophoneBtAction) forControlEvents:(UIControlEventTouchUpInside)];
          
}


#pragma mark - 创建房间
-(void)CreateCloudRoomWithRoomID:(RoomIDBlock) block{
    _callbackBlock = block;
    [self _handleLogin];
}

#pragma mark - 加入房间
-(void)StartCloudRoom:(int)RoomID Psw:(NSString *)Psw UserID:(NSString *)userid NickName:(NSString *)nickName MainVideo:(NSString *)mainVideo
{
    
    _titleStr =mainVideo;
    
    _meetInfo = [[MeetInfo alloc] init];
    
    [_meetInfo setID:RoomID];
    [_meetInfo setPswd:Psw];
    
    _m_nickname =nickName;
    _m_Userid =[NSString stringWithFormat:@"%@_%04zd",userid,[self _randomNumFrom:1 to:9999]];

    // 入会操作
    [self _enterMeeting];
}

#pragma mark - 入会操作
- (void)_enterMeeting {
    
    
    if (_meetInfo.ID > 0) {
        
        [HUDUtil hudShowProgress:@"正在连接中..." animated:YES];
        CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
        
        
        [cloudroomVideoMeeting enterMeeting:_meetInfo.ID pswd:_meetInfo.pswd userID:_m_Userid nikeName:_m_nickname];
    }
}

#pragma mark - 创建房间需要登录
- (void)_handleLogin {
        
    MeetingHelper *meetingHelper = [MeetingHelper shareInstance];
    [meetingHelper readInfo];
      
    if ([NSString stringCheckEmptyOrNil:meetingHelper.account] ||
          [NSString stringCheckEmptyOrNil:meetingHelper.pswd] ||
          [NSString stringCheckEmptyOrNil:meetingHelper.server])
    {
          [meetingHelper resetInfo];
    }
    
    NSString *nickname = meetingHelper.nickname;
    if ([NSString stringCheckEmptyOrNil:nickname]) {
        nickname = [NSString stringWithFormat:@"iOS_%04zd", [self _randomNumFrom:1000 to:9999]];
    }
    
    // 云屋SDK登陆账号,实际开发中,请联系云屋工作人员获取
    NSString *account = meetingHelper.account;
    // 密码通过MD5以后
    NSString *pswd = meetingHelper.pswd;
    // 服务器地址
    NSString *server = meetingHelper.server;
    
    if ([NSString stringCheckEmptyOrNil:server]) {
        [HUDUtil hudShow:@"服务器地址不能为空!" delay:3 animated:YES];
        return;
    }
    
    if ([NSString stringCheckEmptyOrNil:account]) {
        [HUDUtil hudShow:@"账号不能为空!" delay:3 animated:YES];
        return;
    }
    
    if ([NSString stringCheckEmptyOrNil:pswd]) {
        [HUDUtil hudShow:@"密码不能为空!" delay:3 animated:YES];
        return;
    }
    
    NSString *md5Pswd = [NSString md5:meetingHelper.pswd];
    
    MLog(@"server:%@ nickname:%@ account:%@ pswd:%@", server, nickname, account, md5Pswd);
    
    CloudroomVideoMgr *cloudroomVideoMgr = [CloudroomVideoMgr shareInstance];
    CloudroomVideoSDK *cloudroomVideoSDK = [CloudroomVideoSDK shareInstance];
    LoginDat *loginData = [[LoginDat alloc] init];
    [loginData setNickName:nickname];
    [loginData setAuthAcnt:account];
    [loginData setAuthPswd:md5Pswd];
    [loginData setPrivAcnt:nickname];
    
    [meetingHelper writeAccount:account pswd:pswd server:server];
    [meetingHelper writeNickname:nickname];
    
    // 设置服务器地址
    [cloudroomVideoSDK setServerAddr:server];
    
    [HUDUtil hudShowProgress:@"正在连接中..." animated:YES];
    
    // 开始上传日志
    [[CloudroomVideoSDK shareInstance] startLogReport:nickname server:@"logserver.cloudroom.com:12005"];
    
    // 发送"登录"指令
    NSString *cookie = [NSString stringWithFormat:@"%f",CFAbsoluteTimeGetCurrent()];
    [cloudroomVideoMgr login:loginData cookie:cookie];
}

#pragma mark - 登录密码生成随机码
- (NSInteger)_randomNumFrom:(NSInteger)from to:(NSInteger)to {
    return (from + (NSInteger)(arc4random() % (to - from + 1)));
}

#pragma mark - 登陆成功
- (void)loginSuccess:(NSString *)usrID cookie:(NSString *)cookie {
//    [HUDUtil hudHiddenProgress:YES];
//    [HUDUtil hudShowProgress:@"正在创建房间..." animated:YES];
    NSLog(@">>>>>>>>>>>>>>创建房间登录用户ID为:%@",usrID);
    _m_CreateUserid = usrID;
    _titleStr = usrID;
    NSString *createCookie = [NSString stringWithFormat:@"%f", CFAbsoluteTimeGetCurrent()];
        // 发送"创建房间"命令(不设置密码)
    [[CloudroomVideoMgr shareInstance] createMeeting:_titleStr createPswd:NO cookie:createCookie];
}

#pragma mark - 登陆失败
- (void)loginFail:(CRVIDEOSDK_ERR_DEF)sdkErr cookie:(NSString *)cookie {
        
    [HUDUtil hudHiddenProgress:YES];
    
    if (sdkErr == CRVIDEOSDK_NOSERVER_RSP) {
        [HUDUtil hudShow:@"服务器无响应" delay:3 animated:YES];
    }
    else if (sdkErr == CRVIDEOSDK_LOGINSTATE_ERROR) {
        [HUDUtil hudShow:@"登陆状态不对" delay:3 animated:YES];
        [[CloudroomVideoMgr shareInstance] logout];
    }
    else if (sdkErr == CRVIDEOSDK_SOCKETTIMEOUT) {
        [HUDUtil hudShow:@"网络超时" delay:3 animated:YES];
    }
    else {
        [HUDUtil hudShow:@"登录失败" delay:3 animated:YES];
    }
    [self _jumpToPMeetingEx];
}

#pragma mark - 创建房间成功回调
- (void)createMeetingSuccess:(MeetInfo *)meetInfo cookie:(NSString *)cookie {
//    [HUDUtil hudHiddenProgress:YES];
    NSLog(@">>>>>>>>>>>>房间ID为：%d",meetInfo.ID);
    _titleStr = [NSString stringWithFormat:@"房间号:%d",meetInfo.ID];
    _createMeetInfo = meetInfo;
    //进入房间
    [self _enterCreateRoomMeeting];
}

#pragma mark - 创建房间失败回调
- (void)createMeetingFail:(CRVIDEOSDK_ERR_DEF)sdkErr cookie:(NSString *)cookie {
    [HUDUtil hudHiddenProgress:YES];
    NSLog(@"创建房间失败：%u",sdkErr );
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"温馨提示:" message:@"创建房间失败" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *doneAction = [UIAlertAction actionWithTitle:@"好的" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        [self _jumpToPMeetingEx];
    }];
    [alertController addAction:doneAction];
    NSString *version = [UIDevice currentDevice].systemVersion;
           
    if(version.doubleValue>=13) {
               
        alertController.modalPresentationStyle = UIModalPresentationFullScreen;
    }
    [self presentViewController:alertController animated:NO completion:nil];
}

#pragma mark - 进入房间
- (void)_enterCreateRoomMeeting{
        if (_createMeetInfo.ID > 0) {
//           [HUDUtil hudShowProgress:@"正在进入房间..." animated:YES];
           _isCreatingMeeting = true;
           CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
           [cloudroomVideoMeeting enterMeeting:_createMeetInfo.ID pswd:_createMeetInfo.pswd userID:_m_CreateUserid nikeName:_m_CreateUserid];
       }
}

#pragma mark - 处理进入房间
- (void)enterMeetingRslt:(CRVIDEOSDK_ERR_DEF)code {
    
 
    
    if (code == CRVIDEOSDK_NOERR) {
        [self _enterMeetingSuccess];
    } else if (code == CRVIDEOSDK_MEETROOMLOCKED) {
           [HUDUtil hudHiddenProgress:YES];
        [self _enterMeetingFail:@"房间已加锁!"];
    } else {
           [HUDUtil hudHiddenProgress:YES];
        NSLog(@">>>>>进入房间失败！错误码：%d",code);
        [self _enterMeetingFail:@"进入房间失败!"];
    }
}
#pragma mark - 进入房间成功
- (void)_enterMeetingSuccess {
    if(_createMeetInfo.ID > 0 && _isCreatingMeeting)
        _callbackBlock(_createMeetInfo.ID);
    // 打开本地麦克风
    [SDKUtil openLocalMic];
    // 打开本地摄像头
    [SDKUtil openLocalCamera];

    [self _setupForCamera];

    [_TitleLabel setText:_titleStr];
    // 订阅摄像头
    [self _setCamera];
    [self _updateVideoInfo];
    // 设置默认扬声器关闭
    CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
    [cloudroomVideoMeeting setSpeakerMute:YES];
    // 设置默认分辨率: 360*360
    [SDKUtil setRatio:VSIZE_SZ_360];
    // 设置默认帧率: 25
    [SDKUtil setFps:25];
    // 设置默认优先级: 画质优先
    [SDKUtil setPriority:36 min:22];
    // 设置默认宽高比
    [SDKUtil setLocalCameraWHRate:WHRATE_16_9];
    [HUDUtil hudHiddenProgress:YES];
}

#pragma mark - 进入房间失败
- (void)_enterMeetingFail:(NSString *)message {
    [HUDUtil hudShow:message delay:3 animated:YES];
  
    if (_createMeetInfo.ID > 0) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"温馨提示:" message:message preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            _isCreatingMeeting = false;
            [self _jumpToPMeetingEx];
            
        }];
        UIAlertAction *doneAction = [UIAlertAction actionWithTitle:@"重试" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            //重新入会
            if(_isCreatingMeeting)
               [self _enterCreateRoomMeeting];
            else
               [self _enterMeeting];
        }];
        [alertController addAction:cancelAction];
        [alertController addAction:doneAction];
        NSString *version = [UIDevice currentDevice].systemVersion;
        
        if(version.doubleValue>=13) {
            
            alertController.modalPresentationStyle = UIModalPresentationFullScreen;
        }
        [self presentViewController:alertController animated:NO completion:nil];
    }
}

#pragma mark - 房间被结束
- (void)meetingStopped{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"温馨提示:" message:@"房间已结束!" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *doneAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self _jumpToPMeetingEx];
        
    }];
    [alertController addAction:doneAction];
    NSString *version = [UIDevice currentDevice].systemVersion;
    
    if(version.doubleValue>=13) {
        
        alertController.modalPresentationStyle = UIModalPresentationFullScreen;
    }
    [self presentViewController:alertController animated:YES completion:^{}];
}

#pragma mark - 房间掉线
- (void)meetingDropped{
    NSLog(@"房间掉线!");
    [self reEnterMeetingAlert:@"房间掉线"];
}

#pragma mark - 房间掉线重连操作
- (void)reEnterMeetingAlert:(NSString*)message{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"温馨提示:" message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"离开房间" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        _isCreatingMeeting = false;
        [self _jumpToPMeetingEx];
    }];
    UIAlertAction *doneAction = [UIAlertAction actionWithTitle:@"重新登录" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        // 离开房间
        [[CloudroomVideoMeeting shareInstance] exitMeeting];
        // 重新入会
        if(_isCreatingMeeting)
        {
            [self _enterCreateRoomMeeting];
        }
        else
        {
            [self _enterMeeting];
        }
    }];
    [alertController addAction:cancelAction];
    [alertController addAction:doneAction];

    NSString *version = [UIDevice currentDevice].systemVersion;
    
    if(version.doubleValue>=13) {
        
        alertController.modalPresentationStyle = UIModalPresentationFullScreen;
        
    }
    [self presentViewController:alertController animated:NO completion:^{}];
    
}

#pragma mark - 更新房间成员信息
- (void)_updateVideoInfo {
    WeakSelf
    [_ArrLock lock];
    CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
    NSMutableArray <UsrVideoId *> *watchableVideos = [cloudroomVideoMeeting getWatchableVideos];
    if(watchableVideos.count > 0)
    {
        
        [watchableVideos enumerateObjectsUsingBlock:^(UsrVideoId * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSLog(@">>>>>>>>当前房间的用户ID为：%@  _m_CreateUserid：%@，_m_Userid:%@",obj.userId,_m_CreateUserid,_m_Userid);
            if(_isCreatingMeeting)
            {
                if([obj.userId isEqualToString: _m_CreateUserid])
                {
                                     
                     [weakSelf.selfCameraView setUsrVideoId:obj];
                               
                     [watchableVideos removeObject:obj];
                }
            }
            else
            {
                if([obj.userId isEqualToString: _m_Userid])
                {
                    [weakSelf.selfCameraView setUsrVideoId:obj];
                               
                    [watchableVideos removeObject:obj];
                }
            }
        }];
    }
    if(watchableVideos.count>0)
    {
       [weakSelf.cusCameraView setUsrVideoId:watchableVideos[0]];
    }
    [_ArrLock unlock];
}

#pragma mark - 更新摄像头开关UI
- (void)_updateCamera {
    VIDEO_STATUS status = [SDKUtil getLocalCameraStatus];
    
    switch (status) {
        case VCLOSE:
            
            [_CameraButton setImage:[UIImage imageNamed:@"bt_camera_Off"] forState:UIControlStateNormal];
            
            break;
        case VOPEN:
            [_CameraButton setImage:[UIImage imageNamed:@"bt_camera_On"] forState:UIControlStateNormal];
            break;
            
        default:
            break;
    }
    
    
}

#pragma mark - 更新麦克开关UI
- (void)_updateMic {
    AUDIO_STATUS status = [SDKUtil getLocalMicStatus];
    
    switch (status) {
        case ACLOSE:
            
            [_MicButton setImage:[UIImage imageNamed:@"bt_mic_Off"] forState:UIControlStateNormal];

            
            break;
        case AOPEN:
            [_MicButton setImage:[UIImage imageNamed:@"bt_mic_On"] forState:UIControlStateNormal];
            
            
            break;
            
        default:
            break;
    }
    

}


#pragma mark - 本地视频设备状态变化
- (void)videoDevChanged:(NSString *)userID
{
    [self _setCamera];
    [self _updateCamera];
    
    // 订阅摄像头
    [self _updateVideoInfo];
}

#pragma mark - 视频设备状态变化
- (void)videoStatusChanged:(NSString *)userID oldStatus:(VIDEO_STATUS)oldStatus newStatus:(VIDEO_STATUS)newStatus {
    [self _setCamera];
    [self _updateCamera];
    
    [_members enumerateObjectsUsingBlock:^(UsrVideoId * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        
        
        if([userID isEqualToString:obj.userId])
            
            *stop = YES;
        
        if (*stop == YES) {
            
            [_members removeObject:obj];
            
        }
        
    }];

    // 订阅摄像头
    [self _updateVideoInfo];
}

#pragma mark - 本地音频设备有变化
- (void)audioDevChanged{
    [self _updateMic];
}

#pragma mark - 音频设备状态变化
- (void)audioStatusChanged:(NSString *)userID oldStatus:(AUDIO_STATUS)oldStatus newStatus:(AUDIO_STATUS)newStatus {
    
    NSString *myUserID = [[CloudroomVideoMeeting shareInstance] getMyUserID];
    if([myUserID isEqualToString:userID])
    
    [self _updateMic];
}

#pragma mark - 用户加入房间
- (void)userEnterMeeting:(NSString *)userID {
//    NSString *text = [NSString stringWithFormat:@"%@进入房间!", [[CloudroomVideoMeeting shareInstance] getNickName:userID]];
//    [HUDUtil hudShow:text delay:2 animated:YES];
    
    for (MemberInfo *member in [[CloudroomVideoMeeting shareInstance] getAllMembers]) {
        NSLog(@"userId:%@ nickName:%@", member.userId, member.nickName);
    }
    
    [self _updateVideoInfo];
    
}

#pragma mark - 用户离开房间
- (void)userLeftMeeting:(NSString *)userID {
//    NSString *text = [NSString stringWithFormat:@"%@离开房间!", [[CloudroomVideoMeeting shareInstance] getNickName:userID]];
//    [HUDUtil hudShow:text delay:2 animated:YES];
    CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
     NSMutableArray <UsrVideoId *> *watchableVideos = [cloudroomVideoMeeting getWatchableVideos];
     if(watchableVideos.count == 1)
     {
          [self _jumpToPMeetingEx];
     }
    else
    {
           [self _updateVideoInfo];
    }
}

#pragma mark -主视频回调
- (void)notifyMainVideo:(NSString *)userID
{
    
}
#pragma mark -  退出按钮点击事件
- (void)_handleExit {
    
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"提示" message:@"离开房间?" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {}];
    UIAlertAction *done = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        [self _jumpToPMeetingEx];
    }];
    [alertVC addAction:cancel];
    [alertVC addAction:done];
    NSString *version = [UIDevice currentDevice].systemVersion;
    
    if(version.doubleValue>=13) {
        
        alertVC.modalPresentationStyle = UIModalPresentationFullScreen;
    }
    [self presentViewController:alertVC animated:YES completion:nil];
}

#pragma mark - 更多按钮点击事件
- (void)_more{
      WeakSelf
      if(_isLandScape)
      {
          if (!self.popMenu) {
                  self.popMenu = [[JHCustomMenu alloc] initWithDataArr:self.titleArray origin:CGPointMake(weakSelf.moreButton.frame.origin.x, weakSelf.moreButton.frame.origin.y+weakSelf.moreButton.frame.size.height)   width:self.view.frame.size.width*0.3 rowHeight:80];
                  _popMenu.delegate = self;
                  _popMenu.dismiss = ^() {
                      weakSelf.popMenu = nil;
                  };
                  _popMenu.arrImgName = self.logoArrary;
                  [self.view addSubview:_popMenu];
              } else {
                  [_popMenu dismissWithCompletion:^(JHCustomMenu *object) {
                      weakSelf.popMenu = nil;
                  }];
              }
      }
      else{
          if (!self.popMenu) {
                  self.popMenu = [[JHCustomMenu alloc] initWithDataArr:self.titleArray origin:CGPointMake(weakSelf.moreButton.frame.origin.x, weakSelf.moreButton.frame.origin.y+weakSelf.moreButton.frame.size.height)   width:self.view.frame.size.width*0.45 rowHeight:80];
                  _popMenu.delegate = self;
                  _popMenu.dismiss = ^() {
                      weakSelf.popMenu = nil;
                  };
                  _popMenu.arrImgName = self.logoArrary;
                  [self.view addSubview:_popMenu];
              } else {
                  [_popMenu dismissWithCompletion:^(JHCustomMenu *object) {
                      weakSelf.popMenu = nil;
                  }];
              }
      }
}

#pragma mark -  外放按钮点击事件
- (void)SoundBtAction{
    _SpeakerisClose = !_SpeakerisClose;
    
    CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
    
    if(_SpeakerisClose){
        
        [cloudroomVideoMeeting setSpeakerMute:YES];
        [_SoundButton setImage:[UIImage imageNamed:@"bt_sound_Off"] forState:UIControlStateNormal];
        
        [HUDUtil hudShow:@"关闭扬声器" delay:2 animated:YES];
    }
    else{
        [_SoundButton setImage:[UIImage imageNamed:@"bt_sound_On"] forState:UIControlStateNormal];
        [cloudroomVideoMeeting setSpeakerMute:NO];
        
        [HUDUtil hudShow:@"开启扬声器" delay:2 animated:YES];

    }
}

#pragma mark - 主视频点击事件
-(void)MainVideoTapAction
{
    WeakSelf
    // 先取消一个3秒后的方法，保证不管点击多少次，都只有一个方法在3秒后执行
    [UIView cancelPreviousPerformRequestsWithTarget:self selector:@selector(dismissAction) object:nil];
    
    // 3秒后执行的方法
    [self performSelector:@selector(dismissAction) withObject:nil afterDelay:3];

    if(_InfoView.frame.size.height>0)
    {
        [_InfoView updateConstraints:^(MASConstraintMaker *make) {
            make.height.equalTo(@0);
        }];
    }else{
        
        [_InfoView updateConstraints:^(MASConstraintMaker *make) {
            make.height.equalTo(@64);
        }];
        
    }
    
   if(_TopView.isHidden)
   {
       [_TopView setHidden:false];
   }
   else{
        [_TopView setHidden:true];
   }
        

    if(_isShowMore)
    {
        if(_moreButton.isHidden)
        {
            [_moreButton setHidden:false];
        }
        else
        {
            [_moreButton setHidden:true];
        }
    }
    
    if(self.popMenu)
     {
         [_popMenu dismissWithCompletion:^(JHCustomMenu *object) {
                      weakSelf.popMenu = nil;
                  }];
     }
    _StateBarIsHidden = !_StateBarIsHidden;
    
    [self setNeedsStatusBarAppearanceUpdate];
}

// 3秒后执行的方法
- (void)dismissAction
{
    WeakSelf
    [_InfoView updateConstraints:^(MASConstraintMaker *make) {
        
        make.height.equalTo(@0);
    }];
     [_TopView setHidden:true];
     [_moreButton setHidden:true];
    if(self.popMenu)
    {
        [_popMenu dismissWithCompletion:^(JHCustomMenu *object) {
                     weakSelf.popMenu = nil;
                 }];
    }
    
    _StateBarIsHidden = YES;
    [self setNeedsStatusBarAppearanceUpdate];
}

#pragma mark -  麦克风按钮点击事件
- (void)MicrophoneBtAction{
    
    _MicisClose = !_MicisClose;
    
    if (_MicisClose) {
        
        [SDKUtil closeLocalMic];
        
        [HUDUtil hudShow:@"关闭麦克风" delay:2 animated:YES];

        
    } else {
        [SDKUtil openLocalMic];
        [HUDUtil hudShow:@"开启麦克风" delay:2 animated:YES];
    }
    
}

#pragma mark -  摄像头按钮点击事件
- (void)CameraBtAction{
    
    _CameraisClose = !_CameraisClose;
    
    if (_CameraisClose) {
        [SDKUtil closeLocalCamera];
        
        [_selfCameraView clearFrame];
        [_selfCameraView.placeImage setHidden:NO];
        
        [HUDUtil hudShow:@"关闭摄像头" delay:2 animated:YES];
        
    } else {
        [SDKUtil openLocalCamera];
        [_selfCameraView.placeImage setHidden:YES];
        
        [HUDUtil hudShow:@"开启摄像头" delay:2 animated:YES];
    }
    
}

#pragma mark - 切换摄像头
/* 切换摄像头 */
- (void)_handleExCamera {
    
   // [[CloudroomVideoMeeting shareInstance] setSpeakerMute:true];
    
    
    // FIXME: 切换摄像头之前,先检测是否关闭 (king 20180717)
    if (![SDKUtil isLocalCameraOpen]) {
        [HUDUtil hudShow:@"摄像头已关闭" delay:3 animated:YES];
        return;
    }
    
    if ([_cameraArray count] <= 1) {
        MLog(@"无法切换摄像头!");
        return;
    }
    
    if (_curCameraIndex == 0) {
        _curCameraIndex = 1;
    } else {
        _curCameraIndex = 0;
    }
    
    [self _setCamera];
}

#pragma mark - 设置摄像头
- (void)_setupForCamera
{
    CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
    NSString *myUserID = [cloudroomVideoMeeting getMyUserID];
    short curVideoID = [cloudroomVideoMeeting getDefaultVideo:myUserID];
    NSMutableArray <UsrVideoInfo *> *videoes = [cloudroomVideoMeeting getAllVideoInfo:myUserID];
    NSArray<UsrVideoInfo *> *cameraArray = [videoes copy];
    
    for (UsrVideoInfo *video in videoes) {
        if (curVideoID == 0) { // 没有默认设备
            curVideoID = video.videoID;
            [cloudroomVideoMeeting setDefaultVideo:myUserID videoID:curVideoID];
        }
    }
    
    if ([cameraArray count] <= 0) {
        NSLog(@"获取摄像头设备为空!");
        return;
    }
    
    _cameraArray = cameraArray;
}

- (void)_setCamera {
    if ([_cameraArray count] ==0) {
        MLog(@"没有摄像头!");
        return;
    }
    
    if (_curCameraIndex >= [_cameraArray count]) {
        MLog(@"摄像头索引越界!");
        return;
    }
    
    // 设置摄像头设备
    UsrVideoInfo *video = [_cameraArray objectAtIndex:_curCameraIndex];
    [[CloudroomVideoMeeting shareInstance] setDefaultVideo:video.userId videoID:video.videoID];
    MLog(@"当前摄像头为:%@", video.userId);
}

#pragma mark - 离开会议并退出
- (void)_jumpToPMeetingEx {
    // 离开房间
    [[CloudroomVideoMeeting shareInstance] exitMeeting];
    // 注销
    [[CloudroomVideoMgr shareInstance] logout];
    
    _isCreatingMeeting = false;
    // 退出界面
    [self dismissViewControllerAnimated:YES completion:nil];
    
    _isDismiss = YES;
    
    if(_meetInfo)
        _meetInfo = nil;
    if(_createMeetInfo)
        _createMeetInfo = nil;
    _m_Userid = nil;
    _m_CreateUserid = nil;
    _curCameraIndex = 1;
    
    [_cusCameraView setUsrVideoId:nil];
    [_selfCameraView setUsrVideoId:nil];
    [_cusCameraView clearFrame];

    [_members removeAllObjects];

    
    NSNumber *orientationTarget = [NSNumber numberWithInt:UIInterfaceOrientationPortrait];
    [[UIDevice currentDevice] setValue:orientationTarget forKey:@"orientation"];

    NSLog(@"------------ 退出播放器 --------------");
}

#pragma mark - 主动调用离开房间
-(void)leaveRoomWithError:(NSString *)errMsg
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"温馨提示:" message:errMsg preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *doneAction = [UIAlertAction actionWithTitle:@"好的" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        [self _jumpToPMeetingEx];
    }];
    [alertController addAction:doneAction];
    NSString *version = [UIDevice currentDevice].systemVersion;
           
    if(version.doubleValue>=13) {
               
        alertController.modalPresentationStyle = UIModalPresentationFullScreen;
    }
    [self presentViewController:alertController animated:NO completion:nil];
}

#pragma mark - 监听下拉菜单点击
-(void)listenPopupClick:(PopUpClickBlock) block withItemTitleArr:(NSArray *)titleArr logoArr:(NSArray *)logoArr
{
    _isShowMore = true;
    self.titleArray = titleArr;
    self.logoArrary = logoArr;
    _clickBlock = block;
}

#pragma mark  强制横屏代码
- (BOOL)prefersStatusBarHidden
{
    
    return _StateBarIsHidden;
}

#pragma mark - 各种懒加载
-(UIView *)InfoView
{
    if(_InfoView == nil)
    {
        _InfoView = [[UIView alloc]init];
    }
    
    return  _InfoView;
}

-(UILabel *)TitleLabel
{
    if(_TitleLabel == nil)
    {
        _TitleLabel = [[UILabel alloc] init];
    }
    
    return  _TitleLabel;
}

-(UIView *)MainVideoView
{
    if(_MainVideoView == nil)
    {
        _MainVideoView = [[UIView alloc]initWithFrame:self.view.frame];
    }
    
    return  _MainVideoView;
}

-(CustomCameraView *)cusCameraView
{
    if(_cusCameraView == nil)
    {
        _cusCameraView = [[CustomCameraView alloc]initWithFrame:self.view.frame];
    }
    return _cusCameraView;
}



- (NSMutableArray<UsrVideoId *> *)members {
    if (!_members) {
        _members = [NSMutableArray array];
    }
    
    return _members;
}

#pragma mark - 屏幕旋转
-(void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator
{
    if(size.width > size.height)
    {
        _isLandScape = true;
        [self.MainVideoView setFrame:CGRectMake(0, 0, _Screen_height,_Screen_width)];
        [self.cusCameraView setFrame:CGRectMake(0, 0, _Screen_height,_Screen_width)];
        [self.InfoView setFrame:CGRectMake(0, 0, _Screen_height, 64)];
          [self.EndButton setFrame:CGRectMake(_Screen_height*0.05, 20, 40, 40)];
        [self.moreButton setFrame:CGRectMake(_Screen_height*0.95- 40, 20, 40, 40)];
         [_selfCameraView setFrame:CGRectMake(_Screen_height*0.8, 74, _Screen_height*0.2, _Screen_width*0.2)];
         [self.TopView setFrame:CGRectMake(0, _Screen_width*0.8, _Screen_height, _Screen_width*0.2)];
         [_hangoutButton setFrame:CGRectMake(_Screen_height*0.4, 0, _Screen_height*0.2, _Screen_width*0.2)];
         [_SoundButton setFrame:CGRectMake(_Screen_height*0.1, _hangoutButton.frame.size.height/4, _Screen_height*0.1, _hangoutButton.frame.size.height/2)];
        [_MicButton setFrame:CGRectMake(_Screen_height*0.8, _hangoutButton.frame.size.height/4, _Screen_height*0.1, _hangoutButton.frame.size.height/2)];
       
    }else{
        
        _isLandScape = false;
        [self.MainVideoView setFrame:CGRectMake(0, 0, _Screen_width ,_Screen_height)];
        [self.cusCameraView setFrame:CGRectMake(0, 0, _Screen_width, _Screen_height)];
        [self.InfoView setFrame:CGRectMake(0, 0, _Screen_width, 64)];
          [self.EndButton setFrame:CGRectMake(_Screen_width*0.05, 20, 40, 40)];
        [self.moreButton setFrame:CGRectMake(_Screen_width*0.95 - 40, 20, 40, 40)];
         [_selfCameraView setFrame:CGRectMake(_Screen_width*0.7, 74, _Screen_width*0.3, _Screen_height*0.2)];
        [self.TopView setFrame:CGRectMake(0, _Screen_height*0.8, _Screen_width, _Screen_height*0.2)];
        [_hangoutButton setFrame:CGRectMake(_Screen_width*0.4, 0, _Screen_width*0.2, _Screen_height*0.2)];
         [_SoundButton setFrame:CGRectMake(_Screen_width*0.1, _hangoutButton.frame.size.height/4, _Screen_width*0.1, _hangoutButton.frame.size.height/2)];
        [_MicButton setFrame:CGRectMake(_Screen_width*0.8, _hangoutButton.frame.size.height/4, _Screen_width*0.1, _hangoutButton.frame.size.height/2)];
    }
}

#pragma mark - 监听下拉菜单点击
-(void)jhCustomMenu:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   if(_clickBlock)
      _clickBlock(indexPath.row);
}

#pragma mark - 下拉菜单回调点击事件
-(void)checkPatientInfoOnWeb:(int)index withURL:(NSString*)url
{
    PatientInfoWebViewController *vc = [[PatientInfoWebViewController alloc]init];
    // 保证不移除之前的View
    vc.modalPresentationStyle = UIModalPresentationOverCurrentContext;
    [self presentViewController:vc animated:YES completion:^{
      
    }];
    NSString *title =@"";
    if(self.titleArray.count > index)
        title = self.titleArray[index];
   
    [vc loadURL:url WithTitle:title];
}

#pragma mark - 适配全面屏
-(void)viewSafeAreaInsetsDidChange
{
      [super viewSafeAreaInsetsDidChange];
      if(_isLandScape)
      {
            [self.TopView  setFrame:CGRectMake(0, _Screen_width*0.8 - self.view.safeAreaInsets.bottom, _Screen_height, _Screen_width*0.2 +self.view.safeAreaInsets.bottom)];
      }
      else
      {

          [self.TopView  setFrame:CGRectMake(0, _Screen_height*0.8 - self.view.safeAreaInsets.bottom, _Screen_width, _Screen_height*0.2 +self.view.safeAreaInsets.bottom)];
      }
}
@end
