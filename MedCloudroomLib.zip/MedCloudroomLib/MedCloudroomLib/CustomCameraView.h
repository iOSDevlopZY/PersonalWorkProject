//
//  MTwoTwoView.h
//  Meeting
//
//  Created by king on 2018/6/28.
//  Copyright © 2018年 BossKing10086. All rights reserved.
//
#include <CloudroomVideoSDK_IOS/CloudroomVideoSDK_IOS.h>

@interface CustomCameraView : CLCameraView
@property (nonatomic,strong)   UIImageView *placeImage;
@property (nonatomic, strong)  UILabel *titleLabel;
//@property (nonatomic, strong) UILabel *remindLabel;

@end
