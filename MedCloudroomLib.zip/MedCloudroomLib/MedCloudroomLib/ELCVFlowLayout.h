//
//  ELCVFlowLayout.h
//  MedCloudroomLib
//
//  Created by Developer_Yi on 2020/3/31.
//  Copyright © 2020 美迪康yh. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ELCVFlowLayout : UICollectionViewFlowLayout

@end

NS_ASSUME_NONNULL_END
