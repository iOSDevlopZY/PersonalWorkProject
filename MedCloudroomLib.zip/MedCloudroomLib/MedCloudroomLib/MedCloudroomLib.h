//
//  MedCloudroomLib.h
//  MedCloudroomLib
//
//  Created by pg on 2019/11/9.
//  Copyright © 2019年 美迪康yh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MedCloudroomLib : NSObject

-(void)InitCloudroomSDK;

-(void)DeInitCloudSDK;
@end
