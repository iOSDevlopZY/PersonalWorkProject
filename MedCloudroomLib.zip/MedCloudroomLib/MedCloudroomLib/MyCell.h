//
//  MyCell.h
//  exit
//
//  Created by pg on 16/1/22.
//  Copyright © 2016年 美迪康. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CustomCameraView.h"

@interface MyCell : UICollectionViewCell
@property(nonatomic,strong)CustomCameraView *VideoView;
@property(nonatomic,assign)CGFloat width;
@property(nonatomic,assign)CGFloat height;
@property(nonatomic,assign)BOOL isHightLight;

@property (nonatomic,strong) UIView *bottomView; // 底部按钮栏
@property (nonatomic,strong) UIButton *micButton; // 麦克风按钮
@property (nonatomic,strong) UIButton *cameraButton; // 摄像头按钮
@property (nonatomic,strong) UIButton *mainVideoButton; // 摄像头按钮
@property (nonatomic,strong) UILabel *titleLabel;
@property(nonatomic,assign)BOOL isVideoOpen;
@end
