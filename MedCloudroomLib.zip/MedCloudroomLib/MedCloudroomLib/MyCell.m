//
//  MyCell.m
//  exit
//
//  Created by pg on 16/1/22.
//  Copyright © 2016年 美迪康. All rights reserved.
//

#import "MyCell.h"

@implementation MyCell

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //布局
        //获取当前cell高度和宽度
        
        self.isHightLight = NO;
        
        self.width = self.frame.size.width;
        self.height = self.frame.size.height;
        
        self.layer.borderWidth = 1.0;
        self.layer.borderColor = [UIColor grayColor].CGColor;
        
        
        self.backgroundColor = [UIColor blackColor];
        
        self.VideoView = [[CustomCameraView alloc]initWithFrame:CGRectMake(1, 1, self.width-2, self.height-2)];
        
        
        [self.contentView addSubview:self.VideoView];
    }
    return self;
    
}


@end
