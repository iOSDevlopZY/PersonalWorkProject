//
//  MyCell.m
//  exit
//
//  Created by pg on 16/1/22.
//  Copyright © 2016年 美迪康. All rights reserved.
//

#import "MyCell.h"

@implementation MyCell

-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //布局
        //获取当前cell高度和宽度
        
        self.isHightLight = NO;
        
        self.width = self.frame.size.width;
        self.height = self.frame.size.height;
        
        self.layer.borderWidth = 1.0;
        self.layer.borderColor = [UIColor grayColor].CGColor;
        
        
        self.backgroundColor = [UIColor blackColor];
        _titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(1, 1, self.width*0.4, self.height*0.05)];
//        _titleLabel.backgroundColor = UIColorFromRGBA(0, 0, 0, 0.3);
        _titleLabel.textAlignment = NSTextAlignmentLeft;
        _titleLabel.textColor = [UIColor whiteColor];
        [_titleLabel setFont:[UIFont systemFontOfSize:12]];
        [self.contentView addSubview: _titleLabel];
    
        self.VideoView = [[CustomCameraView alloc]initWithFrame:CGRectMake(10, 10, self.width-20, self.height-20)];
        
        
        [self.contentView addSubview:self.VideoView];
        [self.contentView bringSubviewToFront:_titleLabel];
        
        self.bottomView = [[UIView alloc]init];
        [self.bottomView setBackgroundColor:[UIColor clearColor]];
        [self.bottomView setFrame:CGRectMake(1, self.height - 40, self.width-2, 40)];
        [self.contentView addSubview:self.bottomView];
        _micButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_micButton setFrame:CGRectMake(0,self.bottomView.frame.size.height - 40 ,self.bottomView.frame.size.width/4, 40)];

        [_micButton.imageView setContentMode:UIViewContentModeScaleAspectFit];
        [self.bottomView addSubview:_micButton];
        [_micButton setImage:[UIImage imageNamed:@"bt_mic_On"] forState:UIControlStateNormal];
        
        _cameraButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_cameraButton setFrame:CGRectMake(self.bottomView.frame.size.width/4,self.bottomView.frame.size.height - 40, self.bottomView.frame.size.width/4, 40)];
        [_cameraButton.imageView setContentMode:UIViewContentModeScaleAspectFit];
        [self.bottomView addSubview:_cameraButton];
        [_cameraButton setImage:[UIImage imageNamed:@"bt_camera_On"] forState:UIControlStateNormal];
        
        _mainVideoButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [self.bottomView addSubview:_mainVideoButton];
        [_cameraButton.imageView setContentMode:UIViewContentModeScaleAspectFit];
        [_mainVideoButton setFrame:CGRectMake(self.bottomView.frame.size.width/2,self.bottomView.frame.size.height - 40 , self.bottomView.frame.size.width/2, 40)];
        [_mainVideoButton setTitle:@"焦点视频" forState:UIControlStateNormal];
        [_mainVideoButton.titleLabel setFont:[UIFont systemFontOfSize:12]];
        
    
    }
    return self;
    
}

@end
