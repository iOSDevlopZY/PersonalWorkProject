//
//  PatientInfoWebViewController.h
//  MedCloudroomLib
//
//  Created by Developer_Yi on 2020/3/5.
//  Copyright © 2020 美迪康yh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PatientInfoWebViewController : UIViewController

- (void)loadURL:(NSString*) url WithTitle:(NSString *)title;

@end

NS_ASSUME_NONNULL_END
