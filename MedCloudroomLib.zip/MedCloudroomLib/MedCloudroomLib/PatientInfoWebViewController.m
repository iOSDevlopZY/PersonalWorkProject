//
//  PatientInfoWebViewController.m
//  MedCloudroomLib
//
//  Created by Developer_Yi on 2020/3/5.
//  Copyright © 2020 美迪康yh. All rights reserved.
//

#import "PatientInfoWebViewController.h"
#import "HUDUtil.h"
#import "Masonry.h"

#define screenWidth  [UIScreen mainScreen].bounds.size.width
#define screenHeight [UIScreen mainScreen].bounds.size.height
#define WeakSelf __weak typeof(self) weakSelf = self;

@interface PatientInfoWebViewController ()<WKUIDelegate,WKNavigationDelegate>
@property (nonatomic,strong) WKWebView *webView;
@property (nonatomic,strong) UIView *topView;
@property (nonatomic,strong) UIButton *EndButton;
@property (nonatomic,strong) UILabel *titleLabel;

@end

@implementation PatientInfoWebViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
    [self.view setBackgroundColor:[UIColor whiteColor]];
    self.topView = [[UIView alloc]init];
    [self.view addSubview:self.topView];
                 
    [self.topView setBackgroundColor:UIColorFromRGBA(1, 101, 184, 1.0)];
    [self.topView setFrame:CGRectMake(0, 0, screenWidth, 64)];
    
    _EndButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_topView addSubview:_EndButton];
             
    [_EndButton setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    [_EndButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_EndButton setFrame:CGRectMake(screenWidth*0.05, 20, 40, 40)];
     _EndButton.imageView.contentMode = UIViewContentModeScaleAspectFit;
     [_EndButton addTarget:self action:@selector(_handleExit) forControlEvents:(UIControlEventTouchUpInside)];
    
    self.titleLabel = [[UILabel alloc]init];
    [self.titleLabel setTextAlignment:NSTextAlignmentCenter];
    [self.titleLabel setTextColor:[UIColor whiteColor]];
    [self.view addSubview:self.titleLabel];
    [self.titleLabel setFrame:CGRectMake(0, 20, screenWidth, 40)];
    
    self.webView = [[WKWebView alloc]init];
    [self.view addSubview:self.webView];
    [self.webView setFrame:CGRectMake(0, 64, screenWidth, screenHeight - 64)];
    self.webView.UIDelegate = self;
    self.webView.navigationDelegate = self;
}

#pragma mark - 加载网页
- (void)loadURL:(NSString*) url WithTitle:(NSString *)title
{
    [HUDUtil hudShowProgress:@"正在加载" animated:YES];
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]];
    [self.titleLabel setText:title];
}

#pragma mark - 退出网页
- (void)_handleExit
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - WKNavigationDelegate
// 页面开始加载时调用
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation{

}
// 当内容开始返回时调用
- (void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation{

}
// 页面加载完成之后调用
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation{
    [HUDUtil hudHiddenProgress:YES];
}
// 页面加载失败时调用
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation{

}
// 接收到服务器跳转请求之后调用
- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(WKNavigation *)navigation{

}
// 在收到响应后，决定是否跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler{

    NSLog(@"%@",navigationResponse.response.URL.absoluteString);
    //允许跳转
    decisionHandler(WKNavigationResponsePolicyAllow);

}
// 在发送请求之前，决定是否跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{

     NSLog(@"%@",navigationAction.request.URL.absoluteString);
    //允许跳转
    decisionHandler(WKNavigationActionPolicyAllow);

}

- (void)viewWillLayoutSubviews
{
   
}

-(void)viewDidLayoutSubviews
{
    UIDeviceOrientation deviceOrientation = [UIDevice currentDevice].orientation;
        if (UIDeviceOrientationIsLandscape(deviceOrientation))
        {
            [self.topView setFrame:CGRectMake(0, 0, self.view.frame.size.width, 64)];
            [self.webView setFrame:CGRectMake(0, 64, self.view.frame.size.width, self.view.frame.size.height - 64)];
            [_EndButton setFrame:CGRectMake(self.view.frame.size.width*0.05, 20, 40, 40)];
            [self.titleLabel setFrame:CGRectMake(0, 20, self.view.frame.size.width, 40)];
        }
        else if(UIDeviceOrientationIsPortrait(deviceOrientation))
        {
                   [self.topView setFrame:CGRectMake(0, 0, screenWidth, 64)];
                    [self.webView setFrame:CGRectMake(0, 64, screenWidth, screenHeight - 64)];
                    [_EndButton setFrame:CGRectMake(screenWidth*0.05, 20, 40, 40)];
                   [self.titleLabel setFrame:CGRectMake(0, 20, screenWidth, 40)];
        }
    
}
@end
