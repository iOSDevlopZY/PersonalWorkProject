//
//  PatientInfoWebViewController.m
//  MedCloudroomLib
//
//  Created by Developer_Yi on 2020/3/5.
//  Copyright © 2020 美迪康yh. All rights reserved.
//

#import "PatientInfoWebViewController.h"
#import "HUDUtil.h"
#import "Masonry.h"

#define screenWidth  [UIScreen mainScreen].bounds.size.width
#define screenHeight [UIScreen mainScreen].bounds.size.height
#define WeakSelf __weak typeof(self) weakSelf = self;

@interface PatientInfoWebViewController ()<WKUIDelegate,WKNavigationDelegate>
@property (nonatomic,strong) WKWebView *webView;
@property (nonatomic,strong) UIView *topView;
@property (nonatomic,strong) UIButton *EndButton;
@property (nonatomic,strong) UILabel *titleLabel;

@end

@implementation PatientInfoWebViewController

- (void)viewDidLoad {
    WeakSelf
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self.view setBackgroundColor:[UIColor whiteColor]];
    self.topView = [[UIView alloc]init];
    [self.view addSubview:self.topView];
                 
    [self.topView setBackgroundColor:UIColorFromRGBA(1, 101, 184, 1.0)];

    [self.topView makeConstraints:^(MASConstraintMaker *make) {
                     
                     make.top.equalTo(weakSelf.view.top);
                     make.left.equalTo(weakSelf.view.left);
                     make.width.equalTo(weakSelf.view);
                     make.height.equalTo(@64);
                     
    }];
    
    _EndButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_topView addSubview:_EndButton];
             
    [_EndButton setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    [_EndButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
             
    [_EndButton makeConstraints:^(MASConstraintMaker *make) {
                
                 make.top.equalTo(_topView.top).with.offset(20);
                 make.bottom.equalTo(_topView.bottom);
                 make.left.equalTo(_topView.left).with.offset(10);
                 make.width.equalTo(@40);

    }];
     _EndButton.imageView.contentMode = UIViewContentModeScaleAspectFit;
     [_EndButton addTarget:self action:@selector(_handleExit) forControlEvents:(UIControlEventTouchUpInside)];
    
    self.titleLabel = [[UILabel alloc]init];
    [self.titleLabel setTextAlignment:NSTextAlignmentCenter];
    [self.titleLabel setTextColor:[UIColor whiteColor]];
    [self.view addSubview:self.titleLabel];
    [_titleLabel makeConstraints:^(MASConstraintMaker *make) {
                   
                    make.top.equalTo(_topView.top).with.offset(20);
                    make.bottom.equalTo(_topView.bottom);
                    make.left.equalTo(_topView.left);
                    make.right.equalTo(_topView.right);

       }];
    
    self.webView = [[WKWebView alloc]init];
    [self.view addSubview:self.webView];
    [self.webView makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakSelf.view);
        make.right.equalTo(weakSelf.view);
        make.top.equalTo(weakSelf.topView.bottom);
        make.bottom.equalTo(weakSelf.view);
    }];
    self.webView.UIDelegate = self;
    self.webView.navigationDelegate = self;
}

#pragma mark - 加载网页
- (void)loadURL:(NSString*) url WithTitle:(NSString *)title
{
    [HUDUtil hudShowProgress:@"正在加载" animated:YES];
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:url]]];
    [self.titleLabel setText:title];
}

#pragma mark - 退出网页
- (void)_handleExit
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - WKNavigationDelegate
// 页面开始加载时调用
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation{

}
// 当内容开始返回时调用
- (void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation{

}
// 页面加载完成之后调用
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation{
    [HUDUtil hudHiddenProgress:YES];
}
// 页面加载失败时调用
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation{

}
// 接收到服务器跳转请求之后调用
- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(WKNavigation *)navigation{

}
// 在收到响应后，决定是否跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler{

    NSLog(@"%@",navigationResponse.response.URL.absoluteString);
    //允许跳转
    decisionHandler(WKNavigationResponsePolicyAllow);

}
// 在发送请求之前，决定是否跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{

     NSLog(@"%@",navigationAction.request.URL.absoluteString);
    //允许跳转
    decisionHandler(WKNavigationActionPolicyAllow);

}
@end
