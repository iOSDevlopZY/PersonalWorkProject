//
//  PlayerController.h
//  MedCloudroomLib
//
//  Created by pg on 2019/11/11.
//  Copyright © 2019年 美迪康yh. All rights reserved.
//

#import <UIKit/UIKit.h>
// ZY修改，添加房间号回调block
typedef void (^ReturnRoomIDBlock)(int roomID);

@interface PlayerController : UIViewController

@property(nonatomic,assign)BOOL isDismiss;


@property (nonatomic,copy) ReturnRoomIDBlock callbackBlock;

-(void)StartCloudRoom:(int)RoomID Psw:(NSString *)Psw UserID:(NSString *)userid NickName:(NSString *)nickName MainVideo:(NSString *)mainVideo;

//// ZY修改，创建房间
-(void)CreateCloudRoomWithUserID:(NSString *)userID NickName:(NSString *)nickName withReturnRoomID:(ReturnRoomIDBlock)block;

/*麦克风事件*/
- (void)microphoneAction:(BOOL) isMicOn;

/*摄像头时间*/
- (void)cameraAction:(BOOL) isCameraOn;
@end
