//
//  PlayerController.m
//  MedCloudroomLib
//
//  Created by pg on 2019/11/11.
//  Copyright © 2019年 美迪康yh. All rights reserved.
//

#import "PlayerController.h"
//#import <CloudroomVideoSDK_IOS/CloudroomVideoSDK_IOS.h>
#import "CustomCameraView.h"
#import "SDKUtil.h"
#import "HUDUtil.h"
#import "Masonry.h"
#import "MyCell.h"
#import "MeetingHelper.h"

#define WeakSelf __weak typeof(self) weakSelf = self;


static NSString *reuseIdentifier = @"MyCell";

@interface PlayerController ()<CloudroomVideoMeetingCallBack, CloudroomVideoMgrCallBack,UICollectionViewDataSource,UICollectionViewDelegate,UIScrollViewDelegate,UICollectionViewDelegateFlowLayout>

@property(nonatomic,assign)CGFloat Screen_width;
@property(nonatomic,assign)CGFloat Screen_height;
@property(nonatomic,assign)BOOL isLandScape;

@property(nonatomic,strong)CustomCameraView *selfCameraView;
@property(nonatomic,strong)CustomCameraView *cusCameraView;
@property (nonatomic, strong)CLShareView *shareView; /**< 屏幕共享 */

@property(nonatomic,strong)UIPageControl *PageControl;

@property(nonatomic,strong)UIScrollView *MainScrollView;
@property(nonatomic,strong)UIView *MainVideoView;
@property(nonatomic,strong)UIView *InfoView;
@property(nonatomic,strong)UIView *TopView;  // 功能栏

@property (nonatomic, strong) NSMutableArray<UsrVideoId *> *members; /**< 房间成员 */
@property (nonatomic, copy) NSArray<UsrVideoInfo *> *cameraArray; /**< 摄像头集合 */
@property (nonatomic, assign) NSInteger curCameraIndex; /**< 当前摄像头索引 */

@property (nonatomic, copy) NSString *m_nickname; /**< 昵称 */
@property (nonatomic, copy) NSString *m_Userid; /**< 用户id */
@property (nonatomic, copy) NSString *m_CreateUserid;
@property (nonatomic, copy) NSString *titleStr;

@property (nonatomic, strong) MeetInfo *meetInfo;
@property (nonatomic, assign) BOOL isCreatingMeeting;  //ZY修改，添加是否创建房间标志
@property (nonatomic, strong) MeetInfo *createMeetInfo;//ZY修改，创建房间的信息

@property(nonatomic,strong)UICollectionView *VideoListView;  // 视频列表页

@property(nonatomic,strong)UIButton *EndButton;  // 退出按钮
@property(nonatomic,strong)UIButton *SoundButton;  // 外放按钮
@property(nonatomic,strong)UILabel *TitleLabel;  // 标题按钮
@property(nonatomic,strong)UIButton *MicButton;  // 麦克按钮
@property(nonatomic,strong)UIButton *CameraButton; // 摄像头按钮

@property (nonatomic, copy) NSString *curMainVideo; /**< 当前选中到大屏的用户ID */
@property (nonatomic, assign) short curMainVideoID; /**< 当前选中到大屏的videoID */

@property(nonatomic,strong)NSLock *ArrLock;

@property(nonatomic,assign)BOOL StateBarIsHidden;
@property(nonatomic,assign)BOOL isScreenShare;
@property(nonatomic,assign)BOOL MicisClose;
@property(nonatomic,assign)BOOL CameraisClose;
@property(nonatomic,assign)BOOL SpeakerisClose;

@property (nonatomic, strong)UICollectionViewFlowLayout*Collectipnlayout;
@property (nonatomic, strong)MyCell*CurSelectCell;

@end

@implementation PlayerController

- (void)viewDidLoad {
    [super viewDidLoad];
    _isLandScape = false;
    _isCreatingMeeting = false;
    _curCameraIndex = 1;
    
    self.ArrLock = [[NSLock alloc]init];
    
    [self.view setBackgroundColor:[UIColor blackColor]];
    
    NSNumber *orientationTarget = [NSNumber numberWithInt:UIInterfaceOrientationPortrait];
    [[UIDevice currentDevice] setValue:orientationTarget forKey:@"orientation"];

    
    CloudroomVideoSDK *cloudroomVideoSDK = [CloudroomVideoSDK shareInstance];
    [cloudroomVideoSDK setServerAddr:@"www.cloudroom.com"];
    
    NSLog(@"------------ 初始化 --------------");
    
    
    _Screen_width =self.view.bounds.size.width;
    _Screen_height =self.view.bounds.size.height;
    
    
    _isDismiss = NO;
    _StateBarIsHidden = NO;
    _isScreenShare = NO;
    _MicisClose = NO;
    _CameraisClose = NO;
    _SpeakerisClose = NO;
    
}

#pragma mark - 布局视图
-(void)LayoutSubView
{
    WeakSelf
    
    
    // 底部滑动布局
    [self.view addSubview:self.MainScrollView];
    [_MainScrollView setPagingEnabled:YES];
    [_MainScrollView setBounces:YES];
    _MainScrollView.delegate = self;
    _MainScrollView.decelerationRate = UIScrollViewDecelerationRateFast;
    [_MainScrollView makeConstraints:^(MASConstraintMaker *make) {
       
        make.edges.equalTo(weakSelf.view);
        
    }];
    
//    [_MainScrollView setContentSize:CGSizeMake(2*_Screen_width, 0)];
    [_MainScrollView setBackgroundColor:[UIColor blackColor]];
    [_MainScrollView setShowsHorizontalScrollIndicator:NO];
    [_MainScrollView setShowsVerticalScrollIndicator:NO];
    
    
    // 主屏底部View
    [_MainScrollView addSubview:self.MainVideoView];
    
    [_MainVideoView setBackgroundColor:[UIColor blackColor]];
    
    [_MainVideoView makeConstraints:^(MASConstraintMaker *make) {
       
        make.top.equalTo(weakSelf.MainScrollView.top);
        make.left.equalTo(weakSelf.MainScrollView.left);
        make.width.equalTo(weakSelf.MainScrollView);
        make.height.equalTo(weakSelf.MainScrollView);
        
    }];
    
    // 信息栏
    
    
    [self.view addSubview:self.InfoView];
    
    [_InfoView setBackgroundColor:UIColorFromRGBA(1, 101, 184, 1.0)];
    
    [_InfoView makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(weakSelf.MainScrollView.top);
        make.left.equalTo(weakSelf.MainScrollView.left);
        make.width.equalTo(weakSelf.MainScrollView);
        make.height.equalTo(@64);
        
    }];

    
    // 工具栏
    [self.view addSubview:self.TopView];
    [_TopView setBackgroundColor:UIColorFromRGBA(25, 25, 25, 1.0)];

    [_TopView makeConstraints:^(MASConstraintMaker *make) {
        
        make.bottom.equalTo(weakSelf.MainScrollView.bottom);
        make.left.equalTo(weakSelf.MainScrollView.left);
        make.right.equalTo(weakSelf.MainScrollView.right);
        
        make.height.equalTo(@40);
        
    }];
    
    
    
    // 预览
    [_MainVideoView addSubview:self.selfCameraView];
        
    [_selfCameraView makeConstraints:^(MASConstraintMaker *make) {

        make.top.equalTo(weakSelf.InfoView.mas_bottom).with.offset(10);
        make.right.equalTo(weakSelf.MainVideoView.right);

//        make.width.equalTo(weakSelf.MainVideoView.width).multipliedBy(0.3);
//        make.height.equalTo(weakSelf.MainVideoView.height).multipliedBy(0.2);
        
        make.width.equalTo(@120);
        make.height.equalTo(@120);

        
    
    }];
    
    _selfCameraView.layer.borderWidth = 1.0;
    _selfCameraView.layer.borderColor = [UIColor grayColor].CGColor;
    
    
    [_selfCameraView setUsrVideoId:nil];
    
    // 主视频
    [_MainVideoView addSubview:self.cusCameraView];
    
    UITapGestureRecognizer *tapEvent = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(MainVideoTapAction)];
    
    [_cusCameraView addGestureRecognizer:tapEvent];
    
    
    [_cusCameraView makeConstraints:^(MASConstraintMaker *make) {
        
        
        make.top.equalTo(weakSelf.selfCameraView.mas_bottom).with.offset(10);
        make.left.equalTo(weakSelf.MainVideoView.left);
        make.width.equalTo(weakSelf.MainVideoView);
        make.bottom.equalTo(weakSelf.TopView.top).with.offset(-20);
        
    }];
    
    [_cusCameraView setUsrVideoId:nil];
    

    
    
    
    // 桌面共享控件
    [_MainVideoView addSubview:self.shareView];
    UITapGestureRecognizer *tapEvent2 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(MainVideoTapAction)];
    [_shareView addGestureRecognizer:tapEvent2];
    
    [_shareView makeConstraints:^(MASConstraintMaker *make) {
        
        
        make.top.equalTo(weakSelf.selfCameraView.bottom).with.offset(10);
        make.left.equalTo(weakSelf.MainVideoView.left);
        make.width.equalTo(weakSelf.MainVideoView);
        make.bottom.equalTo(weakSelf.TopView.top).with.offset(-20);
        
    }];
    
    _shareView.alpha=0;

    
    
    // 换页下标
    [self.view addSubview:self.PageControl];
    [_PageControl makeConstraints:^(MASConstraintMaker *make) {
        
//        make.top.equalTo(weakSelf.cusCameraView.bottom);
//        make.left.equalTo(weakSelf.MainScrollView.left);
//        make.width.equalTo(weakSelf.MainVideoView);
//        make.bottom.equalTo(weakSelf.TopView.top);
        
        
        
        make.top.equalTo(weakSelf.cusCameraView.mas_bottom);
        make.left.equalTo(weakSelf.MainScrollView.left);
        make.width.equalTo(weakSelf.MainVideoView);
        make.height.equalTo(@20);

    }];
    
    [_PageControl setNumberOfPages:2];
    //注意事件类型
    [_PageControl addTarget:self action:@selector(dealPage:) forControlEvents:UIControlEventValueChanged];
    
    
    // 视频列表
    _Collectipnlayout = [[UICollectionViewFlowLayout alloc]init];
    //设置滑动方向
    _Collectipnlayout.scrollDirection = UICollectionViewScrollDirectionVertical;
    //设置cell大小
    _Collectipnlayout.itemSize = CGSizeMake(_Screen_width/2,_Screen_height/2);
    //设置上下边距
    _Collectipnlayout.minimumLineSpacing = 0;
    _Collectipnlayout.minimumInteritemSpacing = 0;
    
    
    //创建collectionView
    self.VideoListView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:_Collectipnlayout];
    
    
    
    //属性
    self.VideoListView.backgroundColor = [UIColor blackColor];//UIColorFromRGBA(31, 47, 65, 1.0);
    //数据源
    self.VideoListView.dataSource = self;
    self.VideoListView.delegate = self;
    //注册cell
    [self.VideoListView registerClass:[MyCell class] forCellWithReuseIdentifier:reuseIdentifier];
    
    [_MainScrollView addSubview:self.VideoListView];
    
    [_VideoListView setPagingEnabled:YES];
    [_VideoListView setShowsHorizontalScrollIndicator:NO];
    [_VideoListView setShowsVerticalScrollIndicator:NO];
    
    [_VideoListView makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(weakSelf.view.mas_top);
        make.left.equalTo(weakSelf.cusCameraView.mas_right).with.offset(0);
        make.width.equalTo(weakSelf.MainScrollView);
        make.height.equalTo(weakSelf.MainScrollView);
        
    }];
    
    
    
    // 退出
    _EndButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [_InfoView addSubview:_EndButton];

    
    [_EndButton setTitle:@"离开" forState:UIControlStateNormal];
    [_EndButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [_EndButton makeConstraints:^(MASConstraintMaker *make) {
       
        make.top.equalTo(_InfoView.top).with.offset(20);
        make.bottom.equalTo(_InfoView.bottom);
        make.right.equalTo(_InfoView.right).with.offset(-10);
        make.width.equalTo(@40);

    }];

    [_EndButton addTarget:self action:@selector(_handleExit) forControlEvents:(UIControlEventTouchUpInside)];
    
    
    
    
    
    // 外放按钮
    _SoundButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [_InfoView addSubview:_SoundButton];
    
    [_SoundButton setImage:[UIImage imageNamed:@"bt_sound_On"] forState:UIControlStateNormal];
    
    _SoundButton.imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    [_SoundButton makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(_InfoView.top).with.offset(20);
        make.bottom.equalTo(_InfoView.bottom);
        make.left.equalTo(_InfoView.left).with.offset(10);
        make.width.equalTo(@40);

        
    }];
    
    [_SoundButton addTarget:self action:@selector(SoundBtAction) forControlEvents:(UIControlEventTouchUpInside)];
    
    
    // 房间标题
    [_InfoView addSubview:self.TitleLabel];
    [_TitleLabel makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(_InfoView.top).with.offset(20);
        make.bottom.equalTo(_InfoView.bottom);
        make.right.equalTo(_EndButton.left);
        make.left.equalTo(_SoundButton.right);
    }];
    [_TitleLabel setTextAlignment:NSTextAlignmentCenter];
    [_TitleLabel setTextColor:[UIColor whiteColor]];

    
    
    
    // 麦克风按钮
    _MicButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [_TopView addSubview:_MicButton];
    
    [_MicButton setBackgroundImage:[UIImage imageNamed:@"bt_mic_On"] forState:UIControlStateNormal];
    
    [_MicButton makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(_TopView.top);
        make.bottom.equalTo(_TopView.bottom);
        make.left.equalTo(_TopView.left).with.offset(50);
        make.width.equalTo(@40);
        
    }];
    
    [_MicButton addTarget:self action:@selector(MicrophoneBtAction) forControlEvents:(UIControlEventTouchUpInside)];

    
    
    // 摄像头按钮
    _CameraButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [_TopView addSubview:_CameraButton];
    
    [_CameraButton setBackgroundImage:[UIImage imageNamed:@"bt_camera_On"] forState:UIControlStateNormal];
    
    [_CameraButton makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.equalTo(_TopView.top);
        make.bottom.equalTo(_TopView.bottom);
        make.right.equalTo(_TopView.right).with.offset(-50);
        make.width.equalTo(@40);
        
    }];
    
    [_CameraButton addTarget:self action:@selector(CameraBtAction) forControlEvents:(UIControlEventTouchUpInside)];
    
}




- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    // 不灭屏
    [[UIApplication sharedApplication] setIdleTimerDisabled:YES];
    
    // 更新代理
    CloudroomVideoMgr *cloudroomVideoMgr = [CloudroomVideoMgr shareInstance];
    [cloudroomVideoMgr setMgrCallback:self];
    CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
    [cloudroomVideoMeeting setMeetingCallBack:self];
    
    [self LayoutSubView];
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    NSLog(@">>>>>>>>>>>>>>.. View Did Appear");
    [_MainScrollView setContentSize:CGSizeMake(2*_Screen_width, 0)];
    [self MainVideoTapAction];
}


-(void)viewWillDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    
    CloudroomVideoMgr *cloudroomVideoMgr = [CloudroomVideoMgr shareInstance];
    [cloudroomVideoMgr removeMgrCallback:self];
    CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
    [cloudroomVideoMeeting removeMeetingCallBack:self];
    
    
    [[UIApplication sharedApplication] setIdleTimerDisabled:NO];
    
}


-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    
    _isDismiss = YES;

}


-(void)StartCloudRoom:(int)RoomID Psw:(NSString *)Psw UserID:(NSString *)userid NickName:(NSString *)nickName MainVideo:(NSString *)mainVideo
{
    
    _titleStr =mainVideo;
    
    _meetInfo = [[MeetInfo alloc] init];
    
    [_meetInfo setID:RoomID];
    [_meetInfo setPswd:Psw];
    
    _m_nickname =nickName;
    _m_Userid =userid;
    
    // 入会操作
    [self _enterMeeting];
    
}



/* 入会操作 */
- (void)_enterMeeting {
    
    
    if (_meetInfo.ID > 0) {
        
        [HUDUtil hudShowProgress:@"正在进入房间..." animated:YES];
        CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
        
        
        [cloudroomVideoMeeting enterMeeting:_meetInfo.ID pswd:_meetInfo.pswd userID:_m_Userid nikeName:_m_nickname];
    }
}

#pragma mark - ZY修改，创建房间
-(void)CreateCloudRoomWithReturnRoomID:(ReturnRoomIDBlock) block
{
    _callbackBlock = block;
    [self _handleLogin];
}
#pragma mark - ZY修改，创建房间需要登录
- (void)_handleLogin {
        
    MeetingHelper *meetingHelper = [MeetingHelper shareInstance];
    [meetingHelper readInfo];
      
    if ([NSString stringCheckEmptyOrNil:meetingHelper.account] ||
          [NSString stringCheckEmptyOrNil:meetingHelper.pswd] ||
          [NSString stringCheckEmptyOrNil:meetingHelper.server])
    {
          [meetingHelper resetInfo];
    }
    
    NSString *nickname = meetingHelper.nickname;
    if ([NSString stringCheckEmptyOrNil:nickname]) {
        nickname = [NSString stringWithFormat:@"iOS_%04zd", [self _randomNumFrom:1000 to:9999]];
    }
    
    // 云屋SDK登陆账号,实际开发中,请联系云屋工作人员获取
    NSString *account = meetingHelper.account;
    // 密码通过MD5以后
    NSString *pswd = meetingHelper.pswd;
    // 服务器地址
    NSString *server = meetingHelper.server;
    
    if ([NSString stringCheckEmptyOrNil:server]) {
        [HUDUtil hudShow:@"服务器地址不能为空!" delay:3 animated:YES];
        return;
    }
    
    if ([NSString stringCheckEmptyOrNil:account]) {
        [HUDUtil hudShow:@"账号不能为空!" delay:3 animated:YES];
        return;
    }
    
    if ([NSString stringCheckEmptyOrNil:pswd]) {
        [HUDUtil hudShow:@"密码不能为空!" delay:3 animated:YES];
        return;
    }
    
    NSString *md5Pswd = [NSString md5:meetingHelper.pswd];
    
    MLog(@"server:%@ nickname:%@ account:%@ pswd:%@", server, nickname, account, md5Pswd);
    
    CloudroomVideoMgr *cloudroomVideoMgr = [CloudroomVideoMgr shareInstance];
    CloudroomVideoSDK *cloudroomVideoSDK = [CloudroomVideoSDK shareInstance];
    LoginDat *loginData = [[LoginDat alloc] init];
    [loginData setNickName:nickname];
    [loginData setAuthAcnt:account];
    [loginData setAuthPswd:md5Pswd];
    [loginData setPrivAcnt:nickname];
    
    [meetingHelper writeAccount:account pswd:pswd server:server];
    [meetingHelper writeNickname:nickname];
    
    // 设置服务器地址
    [cloudroomVideoSDK setServerAddr:server];
    
    [HUDUtil hudShowProgress:@"正在登录中..." animated:YES];
    
    // 开始上传日志
    [[CloudroomVideoSDK shareInstance] startLogReport:nickname server:@"logserver.cloudroom.com:12005"];
    
    // 发送"登录"指令
    NSString *cookie = [NSString stringWithFormat:@"%f",CFAbsoluteTimeGetCurrent()];
   [cloudroomVideoMgr login:loginData cookie:cookie];
    
    
   
}
// 生成随机码
- (NSInteger)_randomNumFrom:(NSInteger)from to:(NSInteger)to {
    return (from + (NSInteger)(arc4random() % (to - from + 1)));
}

#pragma mark - VideoMgrDelegate
// 登录成功
- (void)loginSuccess:(NSString *)usrID cookie:(NSString *)cookie {
    [HUDUtil hudHiddenProgress:YES];
    [HUDUtil hudShowProgress:@"正在创建房间..." animated:YES];
    NSLog(@">>>>>>>>>>>>>>登录用户ID为:%@",usrID);
    _m_CreateUserid = usrID;
    _titleStr = usrID;
    NSString *createCookie = [NSString stringWithFormat:@"%f", CFAbsoluteTimeGetCurrent()];
        // 发送"创建房间"命令(不设置密码)
    [[CloudroomVideoMgr shareInstance] createMeeting:_titleStr createPswd:NO cookie:createCookie];
}

// 登录失败
- (void)loginFail:(CRVIDEOSDK_ERR_DEF)sdkErr cookie:(NSString *)cookie {
        
    [HUDUtil hudHiddenProgress:YES];
    
    if (sdkErr == CRVIDEOSDK_NOSERVER_RSP) {
        [HUDUtil hudShow:@"服务器无响应" delay:3 animated:YES];
    }
    else if (sdkErr == CRVIDEOSDK_LOGINSTATE_ERROR) {
        [HUDUtil hudShow:@"登陆状态不对" delay:3 animated:YES];
        [[CloudroomVideoMgr shareInstance] logout];
    }
    else if (sdkErr == CRVIDEOSDK_SOCKETTIMEOUT) {
        [HUDUtil hudShow:@"网络超时" delay:3 animated:YES];
    }
    else {
        [HUDUtil hudShow:@"登录失败" delay:3 animated:YES];
    }
    [self _jumpToPMeeting];
}

#pragma mark - ZY修改,创建房间回调
// 创建房间成功回调
- (void)createMeetingSuccess:(MeetInfo *)meetInfo cookie:(NSString *)cookie {
    [HUDUtil hudHiddenProgress:YES];
    NSLog(@">>>>>>>>>>>>房间ID为：%d",meetInfo.ID);
    _titleStr = [NSString stringWithFormat:@"房间号:%d",meetInfo.ID];
    _createMeetInfo = meetInfo;
    //进入房间
    [self _enterCreateRoomMeeting];
}

// 创建房间失败回调
- (void)createMeetingFail:(CRVIDEOSDK_ERR_DEF)sdkErr cookie:(NSString *)cookie {
    [HUDUtil hudHiddenProgress:YES];
    NSLog(@"创建房间失败：%u",sdkErr );
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"温馨提示:" message:@"创建房间失败" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *doneAction = [UIAlertAction actionWithTitle:@"好的" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        [self _jumpToPMeeting];
    }];
    [alertController addAction:doneAction];
    NSString *version = [UIDevice currentDevice].systemVersion;
           
    if(version.doubleValue>=13) {
               
        alertController.modalPresentationStyle = UIModalPresentationFullScreen;
    }
    [self presentViewController:alertController animated:NO completion:nil];
}

#pragma mark - ZY修改，进入自己创建的房间
- (void)_enterCreateRoomMeeting{
    if (_createMeetInfo.ID > 0) {
           [HUDUtil hudShowProgress:@"正在进入房间..." animated:YES];
           _isCreatingMeeting = true;
           CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
           [cloudroomVideoMeeting enterMeeting:_createMeetInfo.ID pswd:_createMeetInfo.pswd userID:_m_CreateUserid nikeName:_m_CreateUserid];
       }
}

#pragma mark - 本地视频设备状态变化
- (void)videoDevChanged:(NSString *)userID
{
    [self _setCamera];
    [self _updateCamera];
    
    // 订阅摄像头
    [self _updateVideoInfo];
}
#pragma mark - 视频设备状态变化
- (void)videoStatusChanged:(NSString *)userID oldStatus:(VIDEO_STATUS)oldStatus newStatus:(VIDEO_STATUS)newStatus {
    [self _setCamera];
    [self _updateCamera];
    
    [_members enumerateObjectsUsingBlock:^(UsrVideoId * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        
        
        if([userID isEqualToString:obj.userId])
            
            *stop = YES;
        
        if (*stop == YES) {
            
            [_members removeObject:obj];
            
        }
        
    }];

    
    // 订阅摄像头
    [self _updateVideoInfo];
}

/* 更新摄像头开关 UI */
- (void)_updateCamera {
    VIDEO_STATUS status = [SDKUtil getLocalCameraStatus];
    
    switch (status) {
        case VCLOSE:
            
            [_CameraButton setBackgroundImage:[UIImage imageNamed:@"bt_camera_Off"] forState:UIControlStateNormal];
            
            break;
        case VOPEN:
            [_CameraButton setBackgroundImage:[UIImage imageNamed:@"bt_camera_On"] forState:UIControlStateNormal];
            break;
            
        default:
            break;
    }
    
    
}

#pragma mark - 本地音频设备有变化
- (void)audioDevChanged{
    [self _updateMic];
}

#pragma mark - 音频设备状态变化
- (void)audioStatusChanged:(NSString *)userID oldStatus:(AUDIO_STATUS)oldStatus newStatus:(AUDIO_STATUS)newStatus {
    
    NSString *myUserID = [[CloudroomVideoMeeting shareInstance] getMyUserID];
    if([myUserID isEqualToString:userID])
    
    [self _updateMic];
}

/* 更新麦克风开关 UI */
- (void)_updateMic {
    AUDIO_STATUS status = [SDKUtil getLocalMicStatus];
    
    switch (status) {
        case ACLOSE:
            
            [_MicButton setBackgroundImage:[UIImage imageNamed:@"bt_mic_Off"] forState:UIControlStateNormal];

            
            break;
        case AOPEN:
            [_MicButton setBackgroundImage:[UIImage imageNamed:@"bt_mic_On"] forState:UIControlStateNormal];
            
            
            break;
            
        default:
            break;
    }
    

}




#pragma mark - 云屋代理 VideoMeetingDelegate
// 入会结果
- (void)enterMeetingRslt:(CRVIDEOSDK_ERR_DEF)code {
    
    [HUDUtil hudHiddenProgress:YES];
    
    if (code == CRVIDEOSDK_NOERR) {
        [self _enterMeetingSuccess];
    } else if (code == CRVIDEOSDK_MEETROOMLOCKED) {
        [self _enterMeetingFail:@"房间已加锁!"];
    } else {
        NSLog(@">>>>>进入房间失败！错误码：%d",code);
        [self _enterMeetingFail:@"进入房间失败!"];
    }
}

- (void)userEnterMeeting:(NSString *)userID {
    NSString *text = [NSString stringWithFormat:@"%@进入房间!", [[CloudroomVideoMeeting shareInstance] getNickName:userID]];
    [HUDUtil hudShow:text delay:2 animated:YES];
    
    for (MemberInfo *member in [[CloudroomVideoMeeting shareInstance] getAllMembers]) {
        NSLog(@"userId:%@ nickName:%@", member.userId, member.nickName);
    }
    
    [self _updateVideoInfo];
    
}

- (void)userLeftMeeting:(NSString *)userID {
    NSString *text = [NSString stringWithFormat:@"%@离开房间!", [[CloudroomVideoMeeting shareInstance] getNickName:userID]];
    [HUDUtil hudShow:text delay:2 animated:YES];
    
    [self _updateVideoInfo];
    
}

// 房间被结束
- (void)meetingStopped{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"温馨提示:" message:@"房间已结束!" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *doneAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self _jumpToPMeeting];
        
    }];
    [alertController addAction:doneAction];
    NSString *version = [UIDevice currentDevice].systemVersion;
    
    if(version.doubleValue>=13) {
        
        alertController.modalPresentationStyle = UIModalPresentationFullScreen;
    }
    [self presentViewController:alertController animated:YES completion:^{}];
}


// 房间掉线
- (void)meetingDropped{
    NSLog(@"房间掉线!");
    [self reEnterMeetingAlert:@"房间掉线"];
}

/* 房间掉线操作 */
- (void)reEnterMeetingAlert:(NSString*)message{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"温馨提示:" message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"离开房间" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        _isCreatingMeeting = false;
        [self _jumpToPMeeting];
    }];
    UIAlertAction *doneAction = [UIAlertAction actionWithTitle:@"重新登录" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        // 离开房间
        [[CloudroomVideoMeeting shareInstance] exitMeeting];
        // ZY修改，重新入会
        if(_isCreatingMeeting)
        {
            [self _enterCreateRoomMeeting];
        }
        else
        {
           [self _enterMeeting];
        }

    }];
    [alertController addAction:cancelAction];
    [alertController addAction:doneAction];

    NSString *version = [UIDevice currentDevice].systemVersion;
    
    if(version.doubleValue>=13) {
        
        alertController.modalPresentationStyle = UIModalPresentationFullScreen;
    }
    [self presentViewController:alertController animated:NO completion:^{}];
    
}

/* 入会成功 */
- (void)_enterMeetingSuccess {
    if(_createMeetInfo.ID > 0 && _isCreatingMeeting)
        _callbackBlock(_createMeetInfo.ID);
    // 打开本地麦克风
    [SDKUtil openLocalMic];
    // 打开本地摄像头
    [SDKUtil openLocalCamera];
    
    [self _setupForCamera];
    
    [_TitleLabel setText:_titleStr];
    // 订阅摄像头
    [self _setCamera];
    [self _updateVideoInfo];
    
    // 设置默认分辨率: 360*360
    [SDKUtil setRatio:VSIZE_SZ_360];
    // 设置默认帧率: 15
    [SDKUtil setFps:25];
    // 设置默认优先级: 画质优先
    //    [SDKUtil setPriority:25 min:22];
    [SDKUtil setPriority:36 min:22];
    // 设置默认宽高比
    [SDKUtil setLocalCameraWHRate:WHRATE_16_9];
}



#pragma mark -主视频回调

- (void)notifyMainVideo:(NSString *)userID
{
    
    WeakSelf
    
    
    NSString *mainVideo = [[CloudroomVideoMeeting shareInstance] getMainVideo];
    _curMainVideo = mainVideo;
    
    
    short videoID = [[CloudroomVideoMeeting shareInstance] getDefaultVideo:mainVideo];
    _curMainVideoID = videoID;
    
    [_members enumerateObjectsUsingBlock:^(UsrVideoId * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        
        
        if([mainVideo isEqualToString:obj.userId] && videoID == obj.videoID)
        *stop = true;
        
        if (*stop == YES) {
            
            UsrVideoId *OldInfo = weakSelf.cusCameraView.usrVideoId;
            
            [weakSelf.cusCameraView setUsrVideoId:obj];
            
            [weakSelf.members removeObject:obj];
            
            if(OldInfo)
            [weakSelf.members addObject:OldInfo];
            
            [weakSelf.VideoListView reloadData];
            
        }
        
    }];


}


#pragma mark - 屏幕共享

// 屏幕共享操作通知
- (void)notifyScreenShareStarted{
    [HUDUtil hudShow:@"屏幕共享已开始" delay:2 animated:YES];
    
    _shareView.alpha = 1.0;
    _cusCameraView.alpha = 0;
    _isScreenShare = YES;
    
    [self _updateVideoInfo];
    
}

- (void)notifyScreenShareStopped{
    [HUDUtil hudShow:@"屏幕共享已结束" delay:2 animated:YES];
    
    _shareView.alpha = 0;
    _cusCameraView.alpha=1.0;
    _isScreenShare = NO;
    
    [self _updateVideoInfo];
}


/**
 入会失败
 @param message 失败信息
 */
- (void)_enterMeetingFail:(NSString *)message {
    [HUDUtil hudShow:message delay:3 animated:YES];
  
    if (_meetInfo.ID > 0 || _createMeetInfo.ID > 0) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"温馨提示:" message:message preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            _isCreatingMeeting = false;
            [self _jumpToPMeeting];
            
        }];
        UIAlertAction *doneAction = [UIAlertAction actionWithTitle:@"重试" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            //ZY修改，重新入会时也要分创建的房间还是加入的房间
            if(_isCreatingMeeting)
               [self _enterCreateRoomMeeting];
            else
               [self _enterMeeting];
        }];
        [alertController addAction:cancelAction];
        [alertController addAction:doneAction];
        NSString *version = [UIDevice currentDevice].systemVersion;
        
        if(version.doubleValue>=13) {
            
            alertController.modalPresentationStyle = UIModalPresentationFullScreen;
        }
        [self presentViewController:alertController animated:NO completion:nil];
    }
}



/**
 初始化摄像头信息
 */
- (void)_setupForCamera {
    CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
    NSString *myUserID = [cloudroomVideoMeeting getMyUserID];
    short curVideoID = [cloudroomVideoMeeting getDefaultVideo:myUserID];
    NSMutableArray <UsrVideoInfo *> *videoes = [cloudroomVideoMeeting getAllVideoInfo:myUserID];
    NSArray<UsrVideoInfo *> *cameraArray = [videoes copy];
    
    for (UsrVideoInfo *video in videoes) {
        if (curVideoID == 0) { // 没有默认设备
            curVideoID = video.videoID;
            [cloudroomVideoMeeting setDefaultVideo:myUserID videoID:curVideoID];
        }
    }
    
    if ([cameraArray count] <= 0) {
        NSLog(@"获取摄像头设备为空!");
        return;
    }
    
    _cameraArray = cameraArray;
}



/**
 设置摄像头
 */
- (void)_setCamera {
    if ([_cameraArray count] ==0) {
        MLog(@"没有摄像头!");
        return;
    }
    
    if (_curCameraIndex >= [_cameraArray count]) {
        MLog(@"摄像头索引越界!");
        return;
    }
    
    // 设置摄像头设备
    UsrVideoInfo *video = [_cameraArray objectAtIndex:_curCameraIndex];
    [[CloudroomVideoMeeting shareInstance] setDefaultVideo:video.userId videoID:video.videoID];
    MLog(@"当前摄像头为:%zd", video.userId);
}





/* 更新房间成员 */
- (void)_updateVideoInfo {
    
    WeakSelf
    
    [_ArrLock lock];
    
    CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
    NSString *myUserID = [cloudroomVideoMeeting getMyUserID];
    NSString *mainVideo = [cloudroomVideoMeeting getMainVideo];
    
    
    
    NSMutableArray <UsrVideoId *> *watchableVideos = [cloudroomVideoMeeting getWatchableVideos];
    
    
    NSMutableArray <UsrVideoId *> *diff = [NSMutableArray array];
    NSMutableArray <UsrVideoId *> *remove = [NSMutableArray array];
    
    // 找到不同元素
    if ([self.members count] <= 0) {
        
        
        [diff addObjectsFromArray:watchableVideos];
    }
    else
    {
        for (UsrVideoId *obj1 in watchableVideos)
        {
            BOOL find = NO;
            
            for (UsrVideoId *obj2 in self.members)
            {
                if ([obj1.userId isEqualToString:obj2.userId] && obj1.videoID == obj2.videoID)
                {
                    find = YES;
                    break;
                }
            }
            
            
            if (find == NO)
            {
                
                [diff addObject:obj1];
                NSLog(@"------添加--------->%@",obj1.userId);
            }
        }
        
        // 找到删除元素
        for (UsrVideoId *obj1 in self.members)
        {
            BOOL find = NO;
            for (UsrVideoId *obj2 in watchableVideos)
            {
                if ([obj1.userId isEqualToString:obj2.userId] && obj1.videoID == obj2.videoID)
                {
                    find = YES;
                    break;
                }
            }
            
            if (find == NO)
            {
                NSLog(@"------删除--------->%@",obj1.userId);
                [remove addObject:obj1];
            }
        }
        
        for (UsrVideoId *usrVideoId in remove) {
            [self.members removeObject:usrVideoId];
            
            
        }
    }
    
    
    [_members addObjectsFromArray:diff];
    
    if(weakSelf.cusCameraView.usrVideoId == nil){
        
      if([mainVideo isEqualToString:@""] && _members.count!=0)
      {
            UsrVideoId *uobj = [_members firstObject];
        
            [_cusCameraView setUsrVideoId:uobj];
            
            _curMainVideo =uobj.userId;
            _curMainVideoID =uobj.videoID;
            
            [_members removeObject:uobj];
        
      }else if (![mainVideo isEqualToString:@""])
      {
        UsrVideoId *videotest =[[UsrVideoId alloc]init];
        videotest.userId =mainVideo;
        videotest.videoID = [cloudroomVideoMeeting getDefaultVideo:mainVideo];
        
        [_cusCameraView setUsrVideoId:videotest];
        _curMainVideo =mainVideo;
        _curMainVideoID =videotest.videoID;
        [_members removeObject:videotest];
      }
    }
    
    
    if(weakSelf.selfCameraView.usrVideoId == nil && _members.count!=0)
    {
        UsrVideoId *videotest =[[UsrVideoId alloc]init];
        videotest.userId =myUserID;
        videotest.videoID = [cloudroomVideoMeeting getDefaultVideo:myUserID];
        
        [weakSelf.selfCameraView setUsrVideoId:videotest];
        
    }


    NSLog(@"------ 当前主视频:%@ id:%d cur:%@ id:%d",mainVideo,[cloudroomVideoMeeting getDefaultVideo:mainVideo],_curMainVideo,[cloudroomVideoMeeting getDefaultVideo:_curMainVideo]);
    
    
    [weakSelf.members enumerateObjectsUsingBlock:^(UsrVideoId * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        

        NSString * userID =obj.userId;
        
        
        if([weakSelf.curMainVideo isEqualToString:userID] && !weakSelf.isScreenShare){
            
            if(weakSelf.cusCameraView.usrVideoId == nil){
              [weakSelf.cusCameraView setUsrVideoId:obj];
            }
            
            
            if(weakSelf.curMainVideoID == obj.videoID)
            [weakSelf.members removeObject:obj];
            
        }
        
        
    }];
    
    
//    [weakSelf.members enumerateObjectsUsingBlock:^(UsrVideoId * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
//        
//        NSString * userID =obj.userId;
//
//        if([myUserID isEqualToString:userID])
//        {
//            [weakSelf.members removeObject:obj];
//            
//        }
//
//    }];

    
    
    
    [_VideoListView reloadData];
    
    [_ArrLock unlock];
}



#pragma mark - getter & setter
- (NSMutableArray<UsrVideoId *> *)members {
    if (!_members) {
        _members = [NSMutableArray array];
    }
    
    return _members;
}

-(CustomCameraView *)cusCameraView
{
    if(_cusCameraView == nil)
    {
        _cusCameraView = [[CustomCameraView alloc]initWithFrame:self.view.frame];
    }
    return _cusCameraView;
}

-(CustomCameraView *)selfCameraView
{
    if(_selfCameraView == nil)
    {
        _selfCameraView = [[CustomCameraView alloc]initWithFrame:self.view.frame];
    }
    return _selfCameraView;
}

-(UIScrollView *)MainScrollView
{
    if(_MainScrollView == nil)
    {
        _MainScrollView = [[UIScrollView alloc]initWithFrame:self.view.frame];
    }
    
    return  _MainScrollView;
}

-(UIView *)MainVideoView
{
    if(_MainVideoView == nil)
    {
        _MainVideoView = [[UIView alloc]initWithFrame:self.view.frame];
    }
    
    return  _MainVideoView;
}

-(UIView *)InfoView
{
    if(_InfoView == nil)
    {
        _InfoView = [[UIView alloc]init];
    }
    
    return  _InfoView;
}


-(UIView *)TopView
{
    if(_TopView == nil)
    {
        _TopView = [[UIView alloc]init];
    }
    
    return  _TopView;
}


-(UIPageControl *)PageControl
{
    if(_PageControl == nil)
    {
        _PageControl = [[UIPageControl alloc]init];
    }
    
    return  _PageControl;
}

-(CLShareView *)shareView
{
    if(_shareView == nil)
    {
        _shareView = [[CLShareView alloc]initWithFrame:self.view.frame];
    }
    
    return  _shareView;
}

-(UILabel *)TitleLabel
{
    if(_TitleLabel == nil)
    {
        _TitleLabel = [[UILabel alloc] init];
    }
    
    return  _TitleLabel;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];


}




#pragma mark  强制横屏代码

// 是否隐藏状态栏
- (BOOL)prefersStatusBarHidden
{
    
    return _StateBarIsHidden;
}





#pragma mark - collectionView Delegate
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    
    return 1;
}


-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.members.count;
    
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    MyCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    
    UsrVideoId *userInfo = _members[indexPath.item];
    
    
    CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
    NSString *nickName = [cloudroomVideoMeeting getNickName:userInfo.userId];
    

    [cell.VideoView.titleLabel setText:nickName];
    
    
    [cell.VideoView setUsrVideoId:userInfo];
    
    return cell;
}




// 点击cell回调
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    if(_isScreenShare)
    {
        [HUDUtil hudShow:@"正在观看屏幕共享,无法点击" delay:2 animated:YES];
        return;
    }
    
    
    MyCell *cell =(MyCell*)[_VideoListView cellForItemAtIndexPath:indexPath];
    
    if(cell == _CurSelectCell && cell.isHightLight)
    {
        
        cell.isHightLight = NO;
        cell.layer.borderWidth = 1.0;
        cell.layer.borderColor = [UIColor whiteColor].CGColor;
        
        
        UsrVideoId *OldInfo = _cusCameraView.usrVideoId;
        
        
        UsrVideoId *NewInfo = _members[indexPath.item];
        
        [self.cusCameraView setUsrVideoId:NewInfo];
        
        [_members removeObject:NewInfo];
        
        if(OldInfo)
            [_members addObject:OldInfo];
        
        [collectionView reloadData];

    }else{
        
        _CurSelectCell.isHightLight = NO;
        _CurSelectCell.layer.borderWidth = 1.0;
        _CurSelectCell.layer.borderColor = [UIColor whiteColor].CGColor;

        cell.isHightLight = YES;
        cell.layer.borderWidth = 1.0;
        cell.layer.borderColor = [UIColor blueColor].CGColor;
        
        _CurSelectCell = cell;

    }
    
}



// 切换主视频
-(void)ChangeMainVideo:(NSString *)MainUserID
{
    
}



#pragma mark - scrollview Delegate

-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    int index = scrollView.contentOffset.x / scrollView.frame.size.width;
    _PageControl.currentPage = index;
}




#pragma mark -  退出按钮
- (void)_handleExit {
    
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"离开房间?" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {}];
    UIAlertAction *done = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        [self _jumpToPMeeting];
    }];
    [alertVC addAction:cancel];
    [alertVC addAction:done];
    NSString *version = [UIDevice currentDevice].systemVersion;
    
    if(version.doubleValue>=13) {
        
        alertVC.modalPresentationStyle = UIModalPresentationFullScreen;
    }
    [self presentViewController:alertVC animated:YES completion:nil];
}

/* 跳转到上一界面 */
- (void)_jumpToPMeeting {
    // 离开房间
    [[CloudroomVideoMeeting shareInstance] exitMeeting];
    // 注销
    [[CloudroomVideoMgr shareInstance] logout];
    
    _isCreatingMeeting = false;
    // 退出界面
    [self dismissViewControllerAnimated:YES completion:nil];
    
    _isDismiss = YES;
    
    [_cusCameraView setUsrVideoId:nil];
    [_selfCameraView setUsrVideoId:nil];
    
    [_cusCameraView clearFrame];
    
    [_members removeAllObjects];
    [_VideoListView reloadData];
    
    NSNumber *orientationTarget = [NSNumber numberWithInt:UIInterfaceOrientationPortrait];
    [[UIDevice currentDevice] setValue:orientationTarget forKey:@"orientation"];

    
    NSLog(@"------------ 退出播放器 --------------");
    
    
}

#pragma mark -  外放按钮
- (void)SoundBtAction{

    _SpeakerisClose = !_SpeakerisClose;
    
    CloudroomVideoMeeting *cloudroomVideoMeeting = [CloudroomVideoMeeting shareInstance];
    
    if(_SpeakerisClose){
        
        [cloudroomVideoMeeting setSpeakerMute:YES];
        [_SoundButton setImage:[UIImage imageNamed:@"bt_sound_Off"] forState:UIControlStateNormal];
        
        [HUDUtil hudShow:@"关闭扬声器" delay:2 animated:YES];
    }
    
    else{
        [_SoundButton setImage:[UIImage imageNamed:@"bt_sound_On"] forState:UIControlStateNormal];
        [cloudroomVideoMeeting setSpeakerMute:NO];
        
        [HUDUtil hudShow:@"开启扬声器" delay:2 animated:YES];

    }


}
#pragma mark -  麦克风按钮
- (void)MicrophoneBtAction{
    
    _MicisClose = !_MicisClose;
    
    if (_MicisClose) {
        
        [SDKUtil closeLocalMic];
        
        [HUDUtil hudShow:@"关闭麦克风" delay:2 animated:YES];

        
    } else {
        [SDKUtil openLocalMic];
        [HUDUtil hudShow:@"开启麦克风" delay:2 animated:YES];
    }
    
}

#pragma mark -  摄像头按钮
- (void)CameraBtAction{
    
    _CameraisClose = !_CameraisClose;
    
    if (_CameraisClose) {
        [SDKUtil closeLocalCamera];
        
        [_selfCameraView clearFrame];
        [_selfCameraView.placeImage setHidden:NO];
        
        [HUDUtil hudShow:@"关闭摄像头" delay:2 animated:YES];
        
    } else {
        [SDKUtil openLocalCamera];
        [_selfCameraView.placeImage setHidden:YES];
        
        [HUDUtil hudShow:@"开启摄像头" delay:2 animated:YES];
    }
    
}



-(void)MainVideoTapAction
{
    // 先取消一个3秒后的方法，保证不管点击多少次，都只有一个方法在3秒后执行
    [UIView cancelPreviousPerformRequestsWithTarget:self selector:@selector(dismissAction) object:nil];
    
    // 3秒后执行的方法
    [self performSelector:@selector(dismissAction) withObject:nil afterDelay:3];
    
    
    
    
    if(_TopView.frame.size.height>0)
    {
      [_TopView updateConstraints:^(MASConstraintMaker *make) {
       
        
        make.height.equalTo(@0);
      }];
        
    }else{
        
        
        [_TopView updateConstraints:^(MASConstraintMaker *make) {
            
            
            make.height.equalTo(@40);
        }];
            
    }
    
    
    if(_InfoView.frame.size.height>0)
    {
        [_InfoView updateConstraints:^(MASConstraintMaker *make) {
            
            
            make.height.equalTo(@0);
        }];
        
        [_EndButton setTitle:@"" forState:UIControlStateNormal];
    }else{
        [_InfoView updateConstraints:^(MASConstraintMaker *make) {
            
            
            make.height.equalTo(@64);
        }];
        
        [_EndButton setTitle:@"离开" forState:UIControlStateNormal];
    }


    _StateBarIsHidden = !_StateBarIsHidden;
    
    [self setNeedsStatusBarAppearanceUpdate];
    
    
}

// 3秒后执行的方法
- (void)dismissAction
{
    
    [_TopView updateConstraints:^(MASConstraintMaker *make) {
        
        
        make.height.equalTo(@0);
    }];
    
    [_InfoView updateConstraints:^(MASConstraintMaker *make) {
        
        
        make.height.equalTo(@0);
    }];
    
    
    _StateBarIsHidden = YES;
    [self setNeedsStatusBarAppearanceUpdate];
    
}



// 屏幕旋转
-(void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator
{
//    [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];
    NSLog(@">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> viewWillTransitionToSize");
    if(size.width > size.height)
    {
        _isLandScape = true;
    }
    else
    {
         _isLandScape = false;
    }
    //  [_TopView setFrame:CGRectMake(0, size.height-40, size.width, 40)];
    //    //设置cell大小
    //    _Collectipnlayout.itemSize = CGSizeMake(size.width/2,size.height/2);
    //
    //    NSArray<__kindof UICollectionViewCell *> *arr = [_VideoListView visibleCells];
    //
    //    for (MyCell *cell in arr) {
    //
    //
    //        [cell.VideoView setFrame:CGRectMake(1, 1, size.width/2-2,size.height/2-2)];
    //
    //    }
    if(_isLandScape)
    {
         [_TopView setFrame:CGRectMake(0, _Screen_width-40, _Screen_height, 40)];
        //设置cell大小
           _Collectipnlayout.itemSize = CGSizeMake(_Screen_height/2,_Screen_width/2);
           
           NSArray<__kindof UICollectionViewCell *> *arr = [_VideoListView visibleCells];
           
           for (MyCell *cell in arr) {

               
               [cell.VideoView setFrame:CGRectMake(1, 1, _Screen_height/2-2,_Screen_width/2-2)];
               
           }
    }
    else
    {
        [_TopView setFrame:CGRectMake(0, _Screen_height-40, _Screen_width, 40)];
            _Collectipnlayout.itemSize = CGSizeMake(_Screen_width/2,_Screen_height/2);
        
            NSArray<__kindof UICollectionViewCell *> *arr = [_VideoListView visibleCells];
        
            for (MyCell *cell in arr) {
        
        
                [cell.VideoView setFrame:CGRectMake(1, 1, _Screen_width/2-2,_Screen_height/2-2)];
        
            }
    }
    
    if(_isLandScape)
    {
        
        [_selfCameraView updateConstraints:^(MASConstraintMaker *make) {
            
            make.width.equalTo(@80);
            make.height.equalTo(@80);

        }];
        [_MainScrollView setContentSize:CGSizeMake(2*_Screen_height,_Screen_width)];
    }else{
       
        [_selfCameraView updateConstraints:^(MASConstraintMaker *make) {
            
            make.width.equalTo(@120);
            make.height.equalTo(@120);
            
        }];
        [_MainScrollView setContentSize:CGSizeMake(2*_Screen_width,_Screen_height)];
    }
    
    if(_PageControl.currentPage == 0)
    {
         [_MainScrollView setContentOffset:CGPointMake(0, 0)];
    }
    else
    {
        CGFloat x;
        if(_isLandScape)
        {
            x = _PageControl.currentPage*_Screen_height;
        }
        else
        {
             x = _PageControl.currentPage*_Screen_width;
        }
        [_MainScrollView setContentOffset:CGPointMake(x, 0)];
    }
//    if(_MainScrollView.contentOffset.x == 0)
//    {
//        NSLog(@">>>>>>>>>>>>>>.. contentOffset.x == 0");
//        [_MainScrollView setContentOffset:CGPointMake(0, 0)];
//    }
//    else
//    {
//        if(_isLandScape)
//        {
//            NSLog(@">>>>>>>>>>>>>>.. contentOffset.x != 0  LandScape");
//            [_MainScrollView setContentOffset:CGPointMake(_Screen_height, 0)];
//        }
//        else
//        {
//            NSLog(@">>>>>>>>>>>>>>.. contentOffset.x != 0 Not LandScape");
//            [_MainScrollView setContentOffset:CGPointMake(_Screen_width, 0)];
//        }
//
//    }
}


// 换页标示
-(void)dealPage:(UIPageControl *)pc
{
    //把序号转化为滚动视图x的偏移
    double x = _MainScrollView.frame.size.width * pc.currentPage;

    [_MainScrollView setContentOffset:CGPointMake(x, 0) animated:YES];
}


#pragma mark - 适配全面屏
-(void)viewSafeAreaInsetsDidChange
{
//      [super viewSafeAreaInsetsDidChange];
     NSLog(@">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> viewSafeAreaInsetsDidChange");
    WeakSelf

       [_TopView updateConstraints:^(MASConstraintMaker *make) {

                  make.top.equalTo(weakSelf.view.bottom).with.offset(-40 - self.view.safeAreaInsets.bottom);
                  make.bottom.equalTo(weakSelf.view.bottom);
                  make.left.equalTo(weakSelf.view.left);
                  make.right.equalTo(weakSelf.view.right);

       }];
    
       [_MicButton updateConstraints:^(MASConstraintMaker *make) {

                  make.top.equalTo(_TopView.top);
              make.bottom.equalTo(_TopView.bottom).with.offset(-self.view.safeAreaInsets.bottom);
                  make.left.equalTo(_TopView.left).with.offset(50);
                  make.width.equalTo(@40);

       }];

       [_CameraButton updateConstraints:^(MASConstraintMaker *make) {

                  make.top.equalTo(_TopView.top);
              make.bottom.equalTo(_TopView.bottom).with.offset(-self.view.safeAreaInsets.bottom);
                  make.right.equalTo(_TopView.right).with.offset(-50);
                  make.width.equalTo(@40);

       }];

        if(_isLandScape)
        {

             [_selfCameraView updateConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(weakSelf.MainVideoView.right).with.offset(-self.view.safeAreaInsets.right);

             }];
        }
        else{

            [_selfCameraView updateConstraints:^(MASConstraintMaker *make) {
                 make.right.equalTo(weakSelf.MainVideoView.right);

            }];

        }
}

#pragma mark - 将图像缩放到指定大小
- (UIImage*)imageCompressWithSimple:(UIImage*)image scaledToSize:(CGSize)size
{
    UIGraphicsBeginImageContext(size);
    [image drawInRect:CGRectMake(0,0,size.width,size.height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}

#pragma mark - 解决scrollView滚动不正常的问题
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    bool isStop = !scrollView.decelerating && !scrollView.tracking && !scrollView.dragging;
    if(isStop)
    {
             CGFloat x;
             if(_isLandScape)
             {
                 x = _PageControl.currentPage*_Screen_height;
             }
             else
             {
                  x = _PageControl.currentPage*_Screen_width;
             }
             [_MainScrollView setContentOffset:CGPointMake(x, 0)];
    }
}
@end
