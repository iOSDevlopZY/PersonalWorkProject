//
//  AppDelegate.h
//  YunwuLibTest
//
//  Created by Developer_Yi on 2020/2/15.
//  Copyright © 2020 medcare. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MedCloudroomLib.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;

@property (nonatomic,strong) MedCloudroomLib *lib;

@end

