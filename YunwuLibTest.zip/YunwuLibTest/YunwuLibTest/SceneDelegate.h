//
//  SceneDelegate.h
//  YunwuLibTest
//
//  Created by Developer_Yi on 2020/2/15.
//  Copyright © 2020 medcare. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

