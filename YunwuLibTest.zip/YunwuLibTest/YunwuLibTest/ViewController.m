//
//  ViewController.m
//  YunwuLibTest
//
//  Created by Developer_Yi on 2020/2/15.
//  Copyright © 2020 medcare. All rights reserved.
//

#import "ViewController.h"
#define screenW [UIScreen mainScreen].bounds.size.width
#define screenH [UIScreen mainScreen].bounds.size.height
@interface ViewController ()
@property (nonatomic,strong) AudioSessionHelper *helper;
@property (nonatomic,strong)  UIButton *speakerBtn;
@property (nonatomic,strong)  UIButton *micBtn;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor blackColor]];
    
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, screenW, screenH*0.15)];
    [titleLabel setTextAlignment:NSTextAlignmentCenter];
    [titleLabel setFont:[UIFont systemFontOfSize:25]];
    [titleLabel setText:@"CloudRoomTest"];
    [self.view addSubview:titleLabel];
    
    UILabel *roomNoLabel =[[UILabel alloc]initWithFrame:CGRectMake(screenW*0.1, screenH*0.15, screenW*0.2, screenH*0.05)];
    [roomNoLabel setText:@"房间号"];
    [roomNoLabel setTextColor:[UIColor whiteColor]];
    [self.view addSubview:roomNoLabel];
    
    self.roomNoTF = [[UITextField alloc]initWithFrame:CGRectMake(screenW*0.35, screenH*0.15, screenW*0.55, screenH*0.05)];
    [self.roomNoTF setPlaceholder:@"请输入房间号"];
    [self.roomNoTF setBorderStyle:UITextBorderStyleRoundedRect];
    [self.view addSubview:self.roomNoTF];
    
    UIButton *enterRoomBtn = [[UIButton alloc]initWithFrame:CGRectMake(screenW*0.1, screenH*0.25, screenW*0.8, screenH*0.05)];
    [enterRoomBtn setTitle:@"加入房间" forState:UIControlStateNormal];
    [enterRoomBtn.layer setBorderColor:[UIColor whiteColor].CGColor];
    [enterRoomBtn.layer setMasksToBounds:YES];
    [enterRoomBtn.layer setCornerRadius:10];
    [enterRoomBtn.layer setBorderWidth:2];
    [enterRoomBtn addTarget:self action:@selector(enterRoom) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:enterRoomBtn];
    
    UIButton * createRoomBtn = [[UIButton alloc]initWithFrame:CGRectMake(screenW*0.1, screenH*0.35, screenW*0.8, screenH*0.05)];
    [createRoomBtn setTitle:@"创建房间" forState:UIControlStateNormal];
    [createRoomBtn.layer setBorderColor:[UIColor whiteColor].CGColor];
    [createRoomBtn.layer setMasksToBounds:YES];
    [createRoomBtn.layer setCornerRadius:10];
    [createRoomBtn.layer setBorderWidth:2];
    [createRoomBtn addTarget:self action:@selector(createRoom) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:createRoomBtn];
    
    
    UIButton *createAudioRoomBtn = [[UIButton alloc]initWithFrame:CGRectMake(screenW*0.1, screenH*0.45, screenW*0.8, screenH*0.05)];
    [createAudioRoomBtn setTitle:@"创建音频房间" forState:UIControlStateNormal];
    [createAudioRoomBtn.layer setBorderColor:[UIColor whiteColor].CGColor];
    [createAudioRoomBtn.layer setMasksToBounds:YES];
    [createAudioRoomBtn.layer setCornerRadius:10];
    [createAudioRoomBtn.layer setBorderWidth:2];
    [createAudioRoomBtn addTarget:self action:@selector(createAudioRoom) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:createAudioRoomBtn];
    
    UIButton *leaveAudioRoomBtn = [[UIButton alloc]initWithFrame:CGRectMake(screenW*0.1, screenH*0.55, screenW*0.8, screenH*0.05)];
    [leaveAudioRoomBtn setTitle:@"退出音频房间" forState:UIControlStateNormal];
    [leaveAudioRoomBtn.layer setBorderColor:[UIColor whiteColor].CGColor];
    [leaveAudioRoomBtn.layer setMasksToBounds:YES];
    [leaveAudioRoomBtn.layer setCornerRadius:10];
    [leaveAudioRoomBtn.layer setBorderWidth:2];
    [leaveAudioRoomBtn addTarget:self action:@selector(leaveAudioRoom) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:leaveAudioRoomBtn];
    
    UIButton *joinAudioRoomBtn = [[UIButton alloc]initWithFrame:CGRectMake(screenW*0.1, screenH*0.65, screenW*0.8, screenH*0.05)];
      [joinAudioRoomBtn setTitle:@"加入音频房间" forState:UIControlStateNormal];
      [joinAudioRoomBtn.layer setBorderColor:[UIColor whiteColor].CGColor];
      [joinAudioRoomBtn.layer setMasksToBounds:YES];
      [joinAudioRoomBtn.layer setCornerRadius:10];
      [joinAudioRoomBtn.layer setBorderWidth:2];
      [joinAudioRoomBtn addTarget:self action:@selector(joinAudioRoom) forControlEvents:UIControlEventTouchUpInside];
      [self.view addSubview:joinAudioRoomBtn];
    
    
     self.speakerBtn = [[UIButton alloc]initWithFrame:CGRectMake(screenW*0.1, screenH*0.8, screenW*0.1, screenH*0.05)];
     [self.speakerBtn setEnabled:false];
     [self.speakerBtn setImage:[UIImage imageNamed:@"bt_sound_On"] forState:UIControlStateNormal];
     [self.speakerBtn addTarget:self action:@selector(speakerClick) forControlEvents:UIControlEventTouchUpInside];
     [self.view addSubview:self.speakerBtn];
    
    
      self.micBtn = [[UIButton alloc]initWithFrame:CGRectMake(screenW*0.8, screenH*0.8, screenW*0.1, screenH*0.05)];
      [self.micBtn setEnabled:false];
      [self.micBtn setImage:[UIImage imageNamed:@"bt_mic_On"] forState:UIControlStateNormal];
      [self.micBtn addTarget:self action:@selector(micClick) forControlEvents:UIControlEventTouchUpInside];
      [self.view addSubview:self.micBtn];
}

#pragma mark - 进入房间
- (void)enterRoom{
    if(![self.roomNoTF.text isEqual:@""])
    {
        CreatingRoomPlayerController *vc =  [[CreatingRoomPlayerController alloc]init];
//        PlayerController *vc =  [[PlayerController alloc]init];
        [vc StartCloudRoom:[self.roomNoTF.text intValue] Psw:@"" UserID:@"iOS_libTest" NickName:@"iOS_libTest" MainVideo:@"iOS测试房间"];
        [self presentViewController:vc animated:YES completion:nil];
    }
    else
    {
         [self showAlert:@"提示" WithMessage:@"房间号不能为空"];
    }
}

#pragma mark - 创建房间
- (void)createRoom{
    CreatingRoomPlayerController *vc =  [[CreatingRoomPlayerController alloc]init];
    [vc CreateCloudRoomWithRoomID:^(int roomID) {
        NSLog(@"创建回调的房间号为:%d",roomID);
    }];
//    PlayerController *vc = [[PlayerController alloc]init];
//    [vc CreateCloudRoomWithReturnRoomID:^(int roomID) {
//        NSLog(@"创建回调的房间号为:%d",roomID);
//    }];
    [self presentViewController:vc animated:YES completion:nil];
}

#pragma mark - 创建音频房间
- (void)createAudioRoom
{
    self.helper = [AudioSessionHelper shareInstance];
    [_helper CreateAudioRoomWithRoomID:^(int roomID) {
        NSLog(@"创建的音频房间ID为：%d",roomID);
        [self.speakerBtn setEnabled:true];
        [self.micBtn setEnabled:true];
    }];
    [self listenRoomUserChange];
    [self listenError];
}

#pragma mark - 离开音频房间
- (void)leaveAudioRoom
{
    [self.speakerBtn setEnabled:false];
    [self.micBtn setEnabled:false];
    [_helper _jumpToPMeeting];
}

#pragma mark - 加入音频房间
- (void)joinAudioRoom{
        if(![self.roomNoTF.text isEqual:@""])
       {
           [_helper StartAudioRoom:[self.roomNoTF.text intValue] Psw:@"" UserID:@"iOS_libTest" NickName:@"iOS_libTest" MainVideo:@"iOS音频房间"];
           [self.speakerBtn setEnabled:true];
           [self.micBtn setEnabled:true];
           [self listenRoomUserChange];
           [self listenError];
       }
       else
       {
           [self showAlert:@"提示" WithMessage:@"房间号不能为空"];
       }
}

#pragma mark - 扬声器点击
- (void)speakerClick{
    _helper.isSpeakerOn = !_helper.isSpeakerOn;
    if(_helper.isSpeakerOn)
    {
         [self.speakerBtn setImage:[UIImage imageNamed:@"bt_sound_On"] forState:UIControlStateNormal];
       
    }
    else
    {
        [self.speakerBtn setImage:[UIImage imageNamed:@"bt_sound_Off"] forState:UIControlStateNormal];
    }
     [_helper speakerAction:_helper.isSpeakerOn];
}

#pragma mark - 麦克风点击
- (void)micClick{
    _helper.isMicOn = !_helper.isMicOn;
    if(_helper.isMicOn)
    {
         [self.micBtn setImage:[UIImage imageNamed:@"bt_mic_On"] forState:UIControlStateNormal];
       
    }
    else
    {
        [self.micBtn setImage:[UIImage imageNamed:@"bt_mic_Off"] forState:UIControlStateNormal];
    }
    [_helper microphoneAction:_helper.isMicOn];
}

#pragma mark - 监听用户加入/离开
- (void)listenRoomUserChange{
    [self.helper listenUserJoinRoom:^(NSString * _Nonnull userID) {
           NSLog(@"%@ 加入房间",userID);
    }];
    
    [self.helper listenUserLeaveRoom:^(NSString * _Nonnull userID) {
            NSLog(@"%@ 离开房间",userID);
    }];
}
#pragma mark - 监听错误
- (void)listenError{
    [self.helper listenError:^(BOOL isCreatingRoomOccur, NSString * _Nonnull error) {
         UIAlertController *ac = [UIAlertController alertControllerWithTitle:@"提示" message:error preferredStyle:UIAlertControllerStyleAlert];
          UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDefault handler:nil];
          [ac addAction:cancelAction];
        if([error isEqualToString:@"RoomDropped"])
        {
                      UIAlertAction *reConnAction = [UIAlertAction actionWithTitle:@"重新连接" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
                          [self->_helper reEnterMeeting];
                       }];
                       [ac addAction:reConnAction];
        }
       
        [self presentViewController:ac animated:YES completion:nil];
    }];
}

#pragma mark - 显示错误
- (void)showAlert:(NSString*)title WithMessage:(NSString*)message
{
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleDefault handler:nil];
    [ac addAction:okAction];
    [self presentViewController:ac animated:YES completion:nil];
}
@end
