//
//  ViewController.m
//  YunwuLibTest
//
//  Created by Developer_Yi on 2020/2/15.
//  Copyright © 2020 medcare. All rights reserved.
//

#import "ViewController.h"
#define screenW [UIScreen mainScreen].bounds.size.width
#define screenH [UIScreen mainScreen].bounds.size.height
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor blackColor]];
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, screenW, screenH*0.15)];
    [titleLabel setTextAlignment:NSTextAlignmentCenter];
    [titleLabel setFont:[UIFont systemFontOfSize:25]];
    [titleLabel setText:@"CloudRoomTest"];
    [self.view addSubview:titleLabel];
    
    UILabel *roomNoLabel =[[UILabel alloc]initWithFrame:CGRectMake(screenW*0.1, screenH*0.15, screenW*0.2, screenH*0.05)];
    [roomNoLabel setText:@"房间号"];
    [roomNoLabel setTextColor:[UIColor whiteColor]];
    [self.view addSubview:roomNoLabel];
    
    self.roomNoTF = [[UITextField alloc]initWithFrame:CGRectMake(screenW*0.35, screenH*0.15, screenW*0.55, screenH*0.05)];
    [self.roomNoTF setPlaceholder:@"请输入房间号"];
    [self.roomNoTF setBorderStyle:UITextBorderStyleRoundedRect];
    [self.view addSubview:self.roomNoTF];
    
    UIButton *enterRoomBtn = [[UIButton alloc]initWithFrame:CGRectMake(screenW*0.1, screenH*0.25, screenW*0.8, screenH*0.05)];
    [enterRoomBtn setTitle:@"加入房间" forState:UIControlStateNormal];
    [enterRoomBtn.layer setBorderColor:[UIColor whiteColor].CGColor];
    [enterRoomBtn.layer setMasksToBounds:YES];
    [enterRoomBtn.layer setCornerRadius:10];
    [enterRoomBtn.layer setBorderWidth:2];
    [enterRoomBtn addTarget:self action:@selector(enterRoom) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:enterRoomBtn];
    
    UIButton * createRoomBtn = [[UIButton alloc]initWithFrame:CGRectMake(screenW*0.1, screenH*0.35, screenW*0.8, screenH*0.05)];
    [createRoomBtn setTitle:@"创建房间" forState:UIControlStateNormal];
    [createRoomBtn.layer setBorderColor:[UIColor whiteColor].CGColor];
    [createRoomBtn.layer setMasksToBounds:YES];
    [createRoomBtn.layer setCornerRadius:10];
    [createRoomBtn.layer setBorderWidth:2];
    [createRoomBtn addTarget:self action:@selector(createRoom) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:createRoomBtn];
}

#pragma mark - 进入房间
- (void)enterRoom{
    if(![self.roomNoTF.text isEqual:@""])
    {
        CreatingRoomPlayerController *vc =  [[CreatingRoomPlayerController alloc]init];
        [vc StartCloudRoom:[self.roomNoTF.text intValue] Psw:@"" UserID:@"iOS_libTest" NickName:@"iOS_libTest" MainVideo:@"iOS测试房间"];
        [self presentViewController:vc animated:YES completion:nil];
    }
    else
    {
        UIAlertController *ac = [UIAlertController alertControllerWithTitle:@"提示" message:@"房间号不能为空" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleDefault handler:nil];
        [ac addAction:okAction];
        [self presentViewController:ac animated:YES completion:nil];
    }
}

#pragma mark - 创建房间
- (void)createRoom{
    CreatingRoomPlayerController *vc =  [[CreatingRoomPlayerController alloc]init];
    [vc CreateCloudRoomWithRoomID:^(int roomID) {
        NSLog(@"创建回调的房间号为:%d",roomID);
    }];
    [self presentViewController:vc animated:YES completion:nil];
}
@end
